# Design Guidelines for "Your HS Expert" - HubSpot Solutions Partner Website

## Design Approach: Modern B2B SaaS Aesthetic
**Selected Approach:** Design System with SaaS industry inspiration  
**Primary References:** HubSpot's brand aesthetic, Linear's typography precision, Stripe's professional minimalism  
**Key Principles:** Trust-building through professionalism, clarity in service offerings, conversion-optimized layout

## Core Design Elements

### A. Color Palette

**Light Mode:**
- Primary Brand: 17 88% 50% (HubSpot-inspired orange, energetic and professional)
- Background: 0 0% 100% (Pure white for maximum clarity)
- Surface: 220 13% 96% (Subtle gray for cards/sections)
- Text Primary: 220 16% 20% (Dark slate for excellent readability)
- Text Secondary: 220 9% 46% (Muted for supporting text)

**Dark Mode:**
- Primary Brand: 17 88% 60% (Slightly lighter orange for dark backgrounds)
- Background: 222 47% 11% (Deep navy-slate)
- Surface: 217 33% 17% (Elevated surface tone)
- Text Primary: 210 40% 98% (Crisp white)
- Text Secondary: 215 20% 65% (Muted blue-gray)

**Accent Colors:**
- Success/CTA Secondary: 142 71% 45% (Teal for positive actions)
- Alert/Highlight: 48 96% 53% (Amber for important callouts)

### B. Typography

**Font Families:**
- Primary: 'Inter' (Google Fonts) - Headings and UI elements
- Secondary: 'Inter' (Google Fonts) - Body text, consistent sans-serif
- Monospace: 'JetBrains Mono' - Code snippets or technical details

**Scale:**
- Hero Headline: text-6xl font-bold (tracking-tight)
- Section Headers: text-4xl font-bold
- Subsection Headers: text-2xl font-semibold
- Body Large: text-lg leading-relaxed
- Body Default: text-base leading-relaxed
- Small/Caption: text-sm

### C. Layout System

**Spacing Primitives:** Use Tailwind units of 4, 8, 12, 16, 20, 24 (e.g., p-4, gap-8, mb-12, py-16, space-y-20, mt-24)

**Container Strategy:**
- Full-width sections with max-w-7xl centered containers
- Content-focused areas: max-w-4xl
- Two-column layouts: grid-cols-1 lg:grid-cols-2 with gap-12

**Vertical Rhythm:**
- Section padding: py-16 md:py-24 lg:py-32
- Component spacing: space-y-12 to space-y-20
- Card internal padding: p-6 md:p-8

### D. Component Library

**Navigation:**
- Sticky header with backdrop-blur effect
- Logo left, navigation center/right, CTA button prominent (orange primary)
- Mobile: Hamburger menu with slide-in drawer

**Hero Section:**
- Large hero image showcasing team collaboration or HubSpot dashboard in action
- 80vh height with gradient overlay (from transparent to background at bottom)
- Split layout: Headline + CTA left, supporting visual/stats right
- Include trust indicators: "Certified Elite Partner" badge, client count

**Service Cards:**
- Three-column grid (lg:grid-cols-3) for service offerings
- Icon at top, title, description, "Learn More" link
- Subtle hover effect: scale-105 transition, shadow-lg
- Background: Surface color with border

**Social Proof Section:**
- Client logo grid (grayscale, hover to color)
- Testimonial cards: Two-column layout with client photo, quote, name, company
- Case study highlights with metrics (percentage increases, revenue impact)

**CTA Sections:**
- Full-width with background color (primary with 10% opacity)
- Centered content: Headline + Description + Button pair (Primary + Ghost)
- Include supporting elements: "Free consultation" badge, response time indicator

**Footer:**
- Three-column structure: Company info + Quick Links + Contact/Newsletter
- Newsletter signup with inline form
- Social media icons, certifications, trust badges
- Copyright and legal links at bottom

**Forms:**
- Contact form with fields: Name, Email, Company, HubSpot Tier (dropdown), Message
- Floating labels, rounded-lg borders
- Primary button for submit
- Include context: "We respond within 24 hours" text

### E. Page Structure & Sections

**Homepage (8 sections):**
1. Hero with large background image
2. Services overview (3-column grid)
3. HubSpot expertise showcase (features with screenshots)
4. Client success stories (testimonials + metrics)
5. Integration capabilities (tech stack display)
6. Pricing/Packages overview
7. Lead magnet CTA (Free audit/consultation)
8. Comprehensive footer

**Strategic Multi-Column Usage:**
- Services: 3-column grid on desktop, stack mobile
- Testimonials: 2-column alternating layout
- Footer: 3-column structure
- Hero: Asymmetric 60/40 split (content/visual)

**Key Differentiators:**
- Orange as hero color (HubSpot brand alignment)
- Professional photography showing real team/office
- Data-driven social proof (specific metrics, not generic claims)
- Technical credibility through certifications and partner badges

## Images

**Hero Section:** Large, high-quality image (1920x1080) showing professional team collaborating over HubSpot dashboard on screens, or modern office environment with orange accent lighting. Position: Full-width background with 40% opacity dark overlay for text contrast.

**Services Section:** Icon-based (no images), use HubSpot-related iconography (gears, charts, automation symbols)

**Social Proof:** Client logos (grayscale grid), actual client photos for testimonials (circular crop, 80x80px)

**CTA Sections:** Abstract geometric patterns or subtle HubSpot interface screenshots as background (20% opacity)

**Accessibility:** All images include descriptive alt text, decorative images use empty alt attributes, hero overlay ensures 4.5:1 contrast ratio for text.