import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, CheckCircle2, Rocket, Database, Settings, Users, TrendingUp, Clock, Shield, Award, Star, Calculator } from "lucide-react";
import { SiHubspot } from "react-icons/si";
import { Link } from "wouter";
import { Helmet } from "react-helmet-async";
import HubSpotCalculator from "@/components/HubSpotCalculator";
import HubOnboardingContent from "@/components/HubOnboardingContent";

export default function HubSpotOnboarding() {
  const features = [
    {
      icon: Database,
      title: "Data Migration",
      description: "Seamless transfer of your existing data with zero loss and complete accuracy."
    },
    {
      icon: Settings,
      title: "Platform Customization",
      description: "We configure your HubSpot to align with your business's specific processes and workflows."
    },
    {
      icon: Shield,
      title: "Security & Compliance",
      description: "Enterprise-grade security setup ensuring your data is protected."
    },
    {
      icon: Users,
      title: "Team Training",
      description: "Comprehensive training to get your team up to speed quickly."
    }
  ];

  const process = [
    {
      step: 1,
      title: "Discovery & Planning",
      description: "We analyze your current systems, understand your needs, and create a detailed migration plan.",
      duration: "1-2 weeks"
    },
    {
      step: 2,
      title: "Data Preparation",
      description: "Clean and organize your data for a smooth transition to HubSpot.",
      duration: "1 week"
    },
    {
      step: 3,
      title: "Portal Configuration",
      description: "Set up your HubSpot portal with custom properties, workflows, and integrations.",
      duration: "2-3 weeks"
    },
    {
      step: 4,
      title: "Migration & Testing",
      description: "Migrate your data and thoroughly test all systems before go-live.",
      duration: "1-2 weeks"
    },
    {
      step: 5,
      title: "Training & Launch",
      description: "Train your team and launch your new HubSpot system with ongoing support.",
      duration: "1 week"
    }
  ];

  const results = [
    { metric: "70%", label: "Decreased Manual Sales Process" },
    { metric: "40%", label: "Time Saved" },
    { metric: "85%", label: "Platform Adoption" }
  ];

  return (
    <div className="min-h-screen">
      <Helmet>
        <title>HubSpot Onboarding & Migration Services | Your HS Expert</title>
        <meta 
          name="description" 
          content="Expert HubSpot onboarding and migration services. Seamless data migration, platform customization, team training, and full implementation support with 70% faster setup and 85% adoption rates." 
        />
        <meta property="og:title" content="HubSpot Onboarding & Migration Services | Your HS Expert" />
        <meta 
          property="og:description" 
          content="Professional HubSpot implementation with data migration, custom workflows, security setup, and comprehensive team training. Get your HubSpot portal configured in 6-9 weeks." 
        />
        <meta property="og:type" content="website" />
        <meta name="keywords" content="HubSpot onboarding, HubSpot migration, HubSpot implementation, HubSpot setup, data migration, CRM implementation, HubSpot partner" />
        <link rel="canonical" href="https://hs-solutions-partner-mason180.replit.app/services/hubspot-onboarding" />
      </Helmet>
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-gradient-to-b from-background via-muted/20 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 mb-12">
            <Button variant="ghost" size="sm" data-testid="button-back" asChild>
              <Link href="/">← Back to Home</Link>
            </Button>
            <Badge className="bg-primary/10 text-primary border-primary/20" data-testid="badge-service">
              <Rocket className="w-3 h-3 mr-1" />
              HubSpot Onboarding & Migration
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight leading-tight">
              Seamless HubSpot <span className="text-primary">Onboarding</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Expert implementation and migration to HubSpot with full guidance from setup to adoption. 
              We ensure a smooth transition with zero downtime.
            </p>
            <div className="flex justify-center gap-4">
              <Button size="lg" asChild data-testid="button-book-call">
                <a href="/book-call?utm_source=service_page&utm_medium=hero&utm_campaign=hubspot_onboarding">
                  Book a Call <ArrowRight className="ml-2 h-5 w-5" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild data-testid="button-view-case-studies">
                <a href="/#case-studies">View Case Studies</a>
              </Button>
            </div>
          </div>

          {/* Results */}
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {results.map((result) => (
              <Card key={result.label} className="text-center p-6" data-testid={`card-result-${result.label.toLowerCase().replace(/\s+/g, '-')}`}>
                <div className="text-4xl font-bold text-primary mb-2">{result.metric}</div>
                <div className="text-sm text-muted-foreground">{result.label}</div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 md:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">What's Included</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Complete onboarding and migration services to get you up and running on HubSpot
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature) => (
              <Card key={feature.title} className="hover-elevate transition-all" data-testid={`card-feature-${feature.title.toLowerCase().replace(/\s+/g, '-')}`}>
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Credibility Section */}
      <section className="py-20 md:py-32 bg-gradient-to-b from-background to-muted/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 max-w-4xl mx-auto">
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                <SiHubspot className="h-10 w-10 text-primary" />
              </div>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
              Trusted HubSpot Solutions Partner
            </h2>
            <p className="text-lg text-muted-foreground">
              We're certified HubSpot experts with a proven track record of successful implementations. 
              Our team brings deep expertise and industry best practices to every project.
            </p>
            
            <div className="grid md:grid-cols-3 gap-8 mt-12 pt-12 border-t">
              <div className="space-y-2" data-testid="stat-projects">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
                  <Award className="h-6 w-6 text-primary" />
                </div>
                <div className="text-3xl font-bold">200+</div>
                <div className="text-sm text-muted-foreground">Successful Projects</div>
              </div>
              
              <div className="space-y-2" data-testid="stat-certified">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
                  <CheckCircle2 className="h-6 w-6 text-primary" />
                </div>
                <div className="text-3xl font-bold">Certified</div>
                <div className="text-sm text-muted-foreground">HubSpot Experts</div>
              </div>
              
              <div className="space-y-2" data-testid="stat-satisfaction">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
                  <Star className="h-6 w-6 text-primary" />
                </div>
                <div className="text-3xl font-bold">95%</div>
                <div className="text-sm text-muted-foreground">Client Satisfaction</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 md:py-32 bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Our Process</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              A proven 5-step approach to ensure successful HubSpot implementation
            </p>
          </div>

          <div className="space-y-6 max-w-4xl mx-auto">
            {process.map((item) => (
              <Card key={item.step} className="hover-elevate transition-all" data-testid={`card-process-${item.step}`}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-6">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-xl font-bold text-primary">{item.step}</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-xl font-semibold">{item.title}</h3>
                        <Badge variant="secondary" className="text-xs">
                          <Clock className="w-3 h-3 mr-1" />
                          {item.duration}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Cost Calculator Section */}
      <section className="py-20 md:py-32 bg-muted/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-12">
            <Badge className="bg-primary/10 text-primary border-primary/20" data-testid="badge-calculator">
              <Calculator className="w-3 h-3 mr-1" />
              Interactive Tool
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
              Estimate Your Investment
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Use our interactive calculator to get a customized estimate for your HubSpot onboarding project based on your specific needs.
            </p>
          </div>

          <HubSpotCalculator />
        </div>
      </section>

      {/* Hub Onboarding Content */}
      <HubOnboardingContent />

      {/* CTA Section */}
      <section className="py-20 md:py-32 bg-gradient-to-b from-background to-muted/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-3xl mx-auto space-y-6">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
              Ready to Get Started?
            </h2>
            <p className="text-lg text-muted-foreground">
              Schedule a free discovery call to discuss your HubSpot onboarding needs and get a custom implementation plan.
            </p>
            <Button size="lg" asChild data-testid="button-cta-book-call">
              <a href="/book-call?utm_source=service_page&utm_medium=bottom_cta&utm_campaign=hubspot_onboarding">
                Book a Call <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
