import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Helmet } from "react-helmet-async";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building2, TrendingUp, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

type CaseStudyItem = {
  id: string;
  type: string;
  status: string;
  title: string;
  slug: string;
  excerpt: string;
  featuredImage?: string;
  company?: string;
  industry?: string;
  metrics?: { metric: string; label: string }[];
  views: number;
  categories: { id: string; name: string; slug: string }[];
  tags: { id: string; name: string; slug: string }[];
};

export default function CaseStudiesList() {
  const { data: caseStudies = [], isLoading } = useQuery<CaseStudyItem[]>({
    queryKey: ["/api/content?type=case-study&status=published"],
  });

  return (
    <div className="min-h-screen">
      <Helmet>
        <title>Client Success Stories | Your HS Expert</title>
        <meta 
          name="description" 
          content="Explore real-world HubSpot implementation success stories. See how we've helped businesses transform their operations with measurable results." 
        />
        <meta property="og:title" content="Client Success Stories | Your HS Expert" />
        <meta 
          property="og:description" 
          content="Real-world HubSpot success stories with measurable results from Your HS Expert." 
        />
        <meta property="og:type" content="website" />
        <link rel="canonical" href={`${window.location.origin}/case-studies`} />
      </Helmet>

      <Header />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/10 via-background to-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Client Success Stories</h1>
            <p className="text-xl text-muted-foreground">
              Discover how we've helped businesses achieve remarkable results with HubSpot
            </p>
          </motion.div>
        </div>
      </section>

      {/* Case Studies Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader>
                    <div className="h-6 bg-muted rounded mb-2" />
                    <div className="h-4 bg-muted rounded w-3/4" />
                  </CardHeader>
                  <CardContent>
                    <div className="h-4 bg-muted rounded mb-2" />
                    <div className="h-4 bg-muted rounded w-5/6" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : caseStudies.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-xl text-muted-foreground">No case studies published yet. Check back soon!</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {caseStudies.map((caseStudy, index) => (
                <motion.div
                  key={caseStudy.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                >
                  <Link href={`/case-studies/${caseStudy.slug}`}>
                    <Card className="h-full hover-elevate active-elevate-2 cursor-pointer transition-all" data-testid={`card-case-study-${caseStudy.id}`}>
                      {caseStudy.featuredImage && (
                        <div className="aspect-video overflow-hidden rounded-t-lg">
                          <img
                            src={caseStudy.featuredImage}
                            alt={caseStudy.title}
                            className="w-full h-full object-cover"
                            data-testid={`img-case-study-featured-${caseStudy.id}`}
                          />
                        </div>
                      )}
                      <CardHeader>
                        <div className="flex items-center gap-2 mb-3 text-sm text-muted-foreground">
                          {caseStudy.company && (
                            <div className="flex items-center gap-1">
                              <Building2 className="w-4 h-4" />
                              <span className="font-medium">{caseStudy.company}</span>
                            </div>
                          )}
                          {caseStudy.industry && (
                            <>
                              <span>•</span>
                              <span>{caseStudy.industry}</span>
                            </>
                          )}
                        </div>
                        <CardTitle className="line-clamp-2" data-testid={`text-case-study-title-${caseStudy.id}`}>
                          {caseStudy.title}
                        </CardTitle>
                        <CardDescription className="line-clamp-3" data-testid={`text-case-study-excerpt-${caseStudy.id}`}>
                          {caseStudy.excerpt}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        {caseStudy.metrics && caseStudy.metrics.length > 0 && (
                          <div className="grid grid-cols-2 gap-3 mb-4">
                            {caseStudy.metrics.slice(0, 2).map((metric, idx) => (
                              <div key={idx} className="text-center p-2 bg-muted rounded-md">
                                <div className="text-lg font-bold text-primary">{metric.metric}</div>
                                <div className="text-xs text-muted-foreground">{metric.label}</div>
                              </div>
                            ))}
                          </div>
                        )}
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex flex-wrap gap-1">
                            {caseStudy.categories.slice(0, 2).map((category) => (
                              <Badge key={category.id} variant="outline" className="text-xs">
                                {category.name}
                              </Badge>
                            ))}
                          </div>
                          <ArrowRight className="w-4 h-4 text-primary" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
