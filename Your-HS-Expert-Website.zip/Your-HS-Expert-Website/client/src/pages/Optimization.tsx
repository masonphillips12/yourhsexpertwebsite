import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, CheckCircle2, TrendingUp, BarChart3, Zap, Target, RefreshCw, LineChart, Gauge, Settings2 } from "lucide-react";
import { SiHubspot } from "react-icons/si";
import { Link } from "wouter";
import { Helmet } from "react-helmet-async";

export default function Optimization() {
  const features = [
    {
      icon: Zap,
      title: "Workflow Automation",
      description: "Streamline processes with intelligent workflows that save time and reduce manual tasks."
    },
    {
      icon: TrendingUp,
      title: "Sales Pipeline Acceleration",
      description: "Optimize deal stages, automate follow-ups, and reduce sales cycle time to close more deals faster."
    },
    {
      icon: BarChart3,
      title: "Performance Analytics",
      description: "Deep insights into what's working and where to focus your optimization efforts."
    },
    {
      icon: Target,
      title: "Lead Scoring & Routing",
      description: "Intelligent lead qualification and routing to maximize sales team efficiency."
    }
  ];

  const process = [
    {
      step: 1,
      title: "Comprehensive Audit",
      description: "Analyze your current HubSpot setup, workflows, and performance to identify optimization opportunities.",
      duration: "1 week"
    },
    {
      step: 2,
      title: "Strategy Development",
      description: "Create a prioritized optimization roadmap based on impact and business goals.",
      duration: "1 week"
    },
    {
      step: 3,
      title: "Implementation",
      description: "Deploy optimizations including workflow automation, property cleanup, and process improvements.",
      duration: "2-4 weeks"
    },
    {
      step: 4,
      title: "A/B Testing",
      description: "Test and validate changes to ensure measurable improvements in key metrics.",
      duration: "2 weeks"
    },
    {
      step: 5,
      title: "Monitoring & Refinement",
      description: "Continuously monitor performance and refine based on data and user feedback.",
      duration: "Ongoing"
    }
  ];

  const results = [
    { metric: "60%", label: "Increased HubSpot Usage" },
    { metric: "80%", label: "Eliminated Manual Tasks" },
    { metric: "95%", label: "Increased Data Hygiene" }
  ];

  return (
    <div className="min-h-screen">
      <Helmet>
        <title>HubSpot Optimization Services | Your HS Expert</title>
        <meta 
          name="description" 
          content="Expert HubSpot optimization services to maximize ROI. Workflow automation, conversion rate optimization, performance analytics, and data cleanup. Get 80% reduction in manual tasks." 
        />
        <meta property="og:title" content="HubSpot Optimization Services | Your HS Expert" />
        <meta 
          property="og:description" 
          content="Optimize your HubSpot portal for maximum efficiency. Workflow automation, lead scoring, analytics setup, and process improvements that drive results." 
        />
        <meta property="og:type" content="website" />
        <meta name="keywords" content="HubSpot optimization, workflow automation, conversion optimization, HubSpot consulting, CRM optimization, marketing automation, HubSpot efficiency" />
        <link rel="canonical" href="https://hs-solutions-partner-mason180.replit.app/services/optimization" />
      </Helmet>
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-gradient-to-b from-background via-muted/20 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 mb-12">
            <Button variant="ghost" size="sm" data-testid="button-back" asChild>
              <Link href="/">← Back to Home</Link>
            </Button>
            <Badge className="bg-primary/10 text-primary border-primary/20" data-testid="badge-service">
              <Gauge className="w-3 h-3 mr-1" />
              HubSpot Optimization
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight leading-tight">
              Maximize Your <span className="text-primary">HubSpot ROI</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Unlock the full potential of your HubSpot investment with expert optimization. 
              We fine-tune your portal for maximum efficiency and results.
            </p>
            <div className="flex justify-center gap-4">
              <Button size="lg" asChild data-testid="button-book-call">
                <a href="/book-call?utm_source=service_page&utm_medium=hero&utm_campaign=optimization">
                  Book a Call <ArrowRight className="ml-2 h-5 w-5" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild data-testid="button-view-case-studies">
                <a href="/#case-studies">View Case Studies</a>
              </Button>
            </div>
          </div>

          {/* Results */}
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {results.map((result) => (
              <Card key={result.label} className="text-center p-6" data-testid={`card-result-${result.label.toLowerCase().replace(/\s+/g, '-')}`}>
                <div className="text-4xl font-bold text-primary mb-2">{result.metric}</div>
                <div className="text-sm text-muted-foreground">{result.label}</div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold tracking-tight">Optimization Services</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Data-driven improvements that transform your HubSpot portal into a revenue-generating machine
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature) => (
              <Card key={feature.title} className="text-center p-6 hover-elevate transition-all" data-testid={`card-feature-${feature.title.toLowerCase().replace(/\s+/g, '-')}`}>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Timeline */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold tracking-tight">Our Approach</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              A systematic process to identify and implement high-impact optimizations
            </p>
          </div>

          <div className="space-y-6">
            {process.map((step) => (
              <Card key={step.step} className="p-6 hover-elevate transition-all" data-testid={`card-process-${step.step}`}>
                <div className="flex items-start gap-6">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold">
                    {step.step}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-semibold">{step.title}</h3>
                      <Badge variant="secondary" className="text-xs">
                        {step.duration}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Credibility Section */}
      <section className="py-16 bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-center gap-8">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                <SiHubspot className="w-8 h-8 text-primary" />
              </div>
              <div>
                <div className="font-bold text-lg">Certified HubSpot Partner</div>
                <div className="text-sm text-muted-foreground">Optimization Specialists</div>
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">100+</div>
              <div className="text-sm text-muted-foreground">Portals Optimized</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">80%</div>
              <div className="text-sm text-muted-foreground">Time Saved</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">95%</div>
              <div className="text-sm text-muted-foreground">Data Quality Improvement</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold tracking-tight mb-6">
            Ready to Optimize Your HubSpot?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Get a free audit and discover how we can improve your HubSpot performance.
          </p>
          <Button size="lg" asChild data-testid="button-cta-book-call">
            <a href="https://meetings.hubspot.com/yourhubspotexpert/intro-call">
              Schedule a Free Audit <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
        </div>
      </section>
    </div>
  );
}
