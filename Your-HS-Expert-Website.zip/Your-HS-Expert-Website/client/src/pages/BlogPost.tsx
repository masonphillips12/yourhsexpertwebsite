import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Helmet } from "react-helmet-async";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Calendar, Clock, Eye, ArrowLeft, TrendingUp, User } from "lucide-react";
import { format } from "date-fns";
import MDEditor from "@uiw/react-md-editor";
import { apiRequest } from "@/lib/queryClient";

type ContentItem = {
  id: string;
  type: string;
  status: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  featuredImage?: string;
  author?: string;
  readingTime?: number;
  views: number;
  publishedAt?: string;
  metaTitle?: string;
  metaDescription?: string;
  categories: { id: string; name: string; slug: string }[];
  tags: { id: string; name: string; slug: string }[];
};

export default function BlogPost() {
  const [, params] = useRoute("/blog/:slug");
  const slug = params?.slug;

  // Fetch the blog post by slug
  const { data: blogPost, isLoading } = useQuery<ContentItem>({
    queryKey: [`/api/content/slug/${slug}`],
    enabled: !!slug,
  });

  // Fetch popular posts for sidebar
  const { data: popularBlogs = [] } = useQuery<ContentItem[]>({
    queryKey: [`/api/content/popular/blog?limit=5`],
  });

  // Increment view count
  const incrementViewMutation = useMutation({
    mutationFn: async (contentId: string) => {
      await apiRequest("POST", `/api/content/${contentId}/view`);
    },
    onError: (error) => {
      console.error("Failed to increment view count:", error);
    },
  });

  useEffect(() => {
    if (blogPost?.id && blogPost.type === "blog" && blogPost.status === "published") {
      incrementViewMutation.mutate(blogPost.id);
    }
  }, [blogPost?.id]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-24 text-center">
          <div className="animate-pulse space-y-4 max-w-3xl mx-auto">
            <div className="h-12 bg-muted rounded w-3/4 mx-auto" />
            <div className="h-6 bg-muted rounded w-1/2 mx-auto" />
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!blogPost || blogPost.type !== "blog" || blogPost.status !== "published") {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-24 text-center">
          <div className="max-w-md mx-auto">
            <h1 className="text-4xl font-bold mb-4">Post Not Found</h1>
            <p className="text-muted-foreground mb-8">
              The blog post you're looking for doesn't exist or has been removed.
            </p>
            <Link href="/blog">
              <Button variant="outline" data-testid="button-back-to-blog">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Blog
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{blogPost.metaTitle || blogPost.title} | Your HS Expert</title>
        <meta 
          name="description" 
          content={blogPost.metaDescription || blogPost.excerpt || "Expert HubSpot insights and tutorials from Your HS Expert."} 
        />
        <meta property="og:title" content={blogPost.title} />
        <meta property="og:description" content={blogPost.excerpt || ""} />
        <meta property="og:type" content="article" />
        {blogPost.featuredImage && <meta property="og:image" content={blogPost.featuredImage} />}
        <link rel="canonical" href={`${window.location.origin}/blog/${blogPost.slug}`} />
      </Helmet>

      <Header />

      {/* Article Header */}
      <article className="pt-24 pb-16 md:pb-24">
        <div className="container mx-auto px-4">
          <div className="max-w-7xl mx-auto">
            {/* Back Navigation */}
            <Link href="/blog">
              <div 
                className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer mb-8"
                data-testid="link-back-to-blog"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Blog
              </div>
            </Link>

            {/* Article Layout */}
            <div className="grid lg:grid-cols-12 gap-12">
              {/* Main Content */}
              <div className="lg:col-span-8">
                {/* Categories */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {blogPost.categories.map((category) => (
                    <Badge 
                      key={category.id} 
                      variant="secondary"
                      data-testid={`badge-category-${category.slug}`}
                    >
                      {category.name}
                    </Badge>
                  ))}
                </div>

                {/* Title */}
                <h1 
                  className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 tracking-tight leading-tight" 
                  data-testid="text-blog-title"
                >
                  {blogPost.title}
                </h1>

                {/* Meta Information */}
                <div className="flex flex-wrap items-center gap-4 md:gap-6 text-sm text-muted-foreground mb-8">
                  {blogPost.author && (
                    <div className="flex items-center gap-2" data-testid="text-blog-author">
                      <User className="w-4 h-4" />
                      <span className="font-medium">{blogPost.author}</span>
                    </div>
                  )}
                  {blogPost.publishedAt && (
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>{format(new Date(blogPost.publishedAt), "MMMM d, yyyy")}</span>
                    </div>
                  )}
                  {blogPost.readingTime && (
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      <span>{blogPost.readingTime} min read</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    <span data-testid="text-blog-views">{blogPost.views} views</span>
                  </div>
                </div>

                <Separator className="mb-8" />

                {/* Featured Image */}
                {blogPost.featuredImage && (
                  <div className="relative aspect-video overflow-hidden rounded-xl mb-12 bg-muted">
                    <img
                      src={blogPost.featuredImage}
                      alt={blogPost.title}
                      className="w-full h-full object-cover"
                      data-testid="img-blog-featured"
                    />
                  </div>
                )}

                {/* Article Content */}
                <div 
                  className="prose prose-lg max-w-none dark:prose-invert
                    prose-headings:font-bold prose-headings:tracking-tight
                    prose-h2:text-3xl prose-h2:mt-12 prose-h2:mb-6
                    prose-h3:text-2xl prose-h3:mt-8 prose-h3:mb-4
                    prose-p:text-base prose-p:leading-relaxed prose-p:text-foreground/90
                    prose-a:text-primary prose-a:no-underline hover:prose-a:underline
                    prose-strong:text-foreground prose-strong:font-semibold
                    prose-ul:my-6 prose-ol:my-6
                    prose-li:text-foreground/90 prose-li:leading-relaxed
                    prose-code:text-primary prose-code:bg-primary/10 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded
                    prose-blockquote:border-l-primary prose-blockquote:bg-primary/5 prose-blockquote:py-1 prose-blockquote:px-6
                    prose-img:rounded-lg
                    [&_.wmde-markdown]:!bg-transparent [&_.wmde-markdown]:!text-foreground
                    [&_.wmde-markdown_h1]:!text-foreground [&_.wmde-markdown_h2]:!text-foreground [&_.wmde-markdown_h3]:!text-foreground
                    [&_.wmde-markdown_p]:!text-foreground/90 [&_.wmde-markdown_li]:!text-foreground/90"
                  data-testid="content-blog-body"
                >
                  <MDEditor.Markdown source={blogPost.content} />
                </div>

                {/* Tags Section */}
                {blogPost.tags.length > 0 && (
                  <div className="mt-16 pt-8 border-t">
                    <h3 className="text-sm font-semibold text-muted-foreground mb-4">TAGS</h3>
                    <div className="flex flex-wrap gap-2">
                      {blogPost.tags.map((tag) => (
                        <Badge 
                          key={tag.id} 
                          variant="outline"
                          className="text-sm"
                          data-testid={`badge-tag-${tag.slug}`}
                        >
                          #{tag.name}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Sidebar */}
              <aside className="lg:col-span-4">
                <div className="sticky top-24 space-y-8">
                  {/* Popular Posts */}
                  {popularBlogs.length > 0 && (
                    <Card className="overflow-hidden">
                      <CardHeader className="border-b bg-muted/30">
                        <CardTitle className="flex items-center gap-2 text-lg">
                          <TrendingUp className="w-5 h-5 text-primary" />
                          Popular Posts
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-0">
                        <div className="divide-y">
                          {popularBlogs.map((post) => (
                            <Link key={post.id} href={`/blog/${post.slug}`}>
                              <div 
                                className="group p-4 hover-elevate active-elevate-2 cursor-pointer transition-all" 
                                data-testid={`link-popular-post-${post.id}`}
                              >
                                <h4 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors mb-2 leading-snug">
                                  {post.title}
                                </h4>
                                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                                  {post.readingTime && (
                                    <div className="flex items-center gap-1">
                                      <Clock className="w-3 h-3" />
                                      <span>{post.readingTime} min</span>
                                    </div>
                                  )}
                                  <div className="flex items-center gap-1">
                                    <Eye className="w-3 h-3" />
                                    <span>{post.views} views</span>
                                  </div>
                                </div>
                              </div>
                            </Link>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* CTA Card */}
                  <Card className="bg-primary/5 border-primary/20">
                    <CardContent className="p-6">
                      <h3 className="text-lg font-semibold mb-2">
                        Ready to optimize your HubSpot?
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        Book a free consultation with our HubSpot experts
                      </p>
                      <Link 
                        href={`/book-call?utm_source=blog&utm_medium=content&utm_campaign=${blogPost.slug}&utm_content=sidebar_cta`}
                      >
                        <Button className="w-full" data-testid="button-book-consultation">
                          Book a Call
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                </div>
              </aside>
            </div>
          </div>
        </div>
      </article>

      <Footer />
    </div>
  );
}
