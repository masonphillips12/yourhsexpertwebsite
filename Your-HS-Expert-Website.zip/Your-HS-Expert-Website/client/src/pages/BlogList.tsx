import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Helmet } from "react-helmet-async";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

type ContentItem = {
  id: string;
  type: string;
  status: string;
  title: string;
  slug: string;
  excerpt: string;
  featuredImage?: string;
  author?: string;
  readingTime?: number;
  views: number;
  publishedAt?: string;
  categories: { id: string; name: string; slug: string }[];
  tags: { id: string; name: string; slug: string }[];
};

export default function BlogList() {
  const { data: blogs = [], isLoading } = useQuery<ContentItem[]>({
    queryKey: ["/api/content?type=blog&status=published"],
  });

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Blog - HubSpot Tips & Insights | Your HS Expert</title>
        <meta 
          name="description" 
          content="Expert insights, tutorials, and best practices for HubSpot implementation, migration, and optimization. Learn from certified HubSpot Solutions Partners." 
        />
        <meta property="og:title" content="Blog - HubSpot Tips & Insights | Your HS Expert" />
        <meta 
          property="og:description" 
          content="Expert HubSpot insights and tutorials from certified Solutions Partners." 
        />
        <meta property="og:type" content="website" />
        <link rel="canonical" href={`${window.location.origin}/blog`} />
      </Helmet>

      <Header />

      {/* Hero Section */}
      <section className="relative py-24 md:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-background" />
        <div className="container mx-auto px-4 relative">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              Latest Insights
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 tracking-tight">
              HubSpot Insights & Tips
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              Expert guidance, best practices, and tutorials from certified HubSpot Solutions Partners
            </p>
          </motion.div>
        </div>
      </section>

      {/* Blog Posts Grid */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-7xl mx-auto">
            {isLoading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Card key={i} className="overflow-hidden">
                    <div className="aspect-[16/9] bg-muted animate-pulse" />
                    <CardHeader className="space-y-3">
                      <div className="h-4 bg-muted rounded animate-pulse w-1/3" />
                      <div className="h-6 bg-muted rounded animate-pulse" />
                      <div className="h-4 bg-muted rounded animate-pulse" />
                      <div className="h-4 bg-muted rounded animate-pulse w-5/6" />
                    </CardHeader>
                  </Card>
                ))}
              </div>
            ) : blogs.length === 0 ? (
              <div className="text-center py-24">
                <div className="max-w-md mx-auto">
                  <h3 className="text-2xl font-semibold mb-3">No posts yet</h3>
                  <p className="text-muted-foreground mb-8">
                    We're working on some great content. Check back soon for expert HubSpot insights!
                  </p>
                  <Link href="/book-call?utm_source=blog&utm_medium=content&utm_campaign=blog_index&utm_content=empty_state_cta">
                    <Button data-testid="button-contact">
                      Get in Touch
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {blogs.map((blog, index) => (
                  <motion.div
                    key={blog.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <Link href={`/blog/${blog.slug}`}>
                      <Card 
                        className="group h-full overflow-hidden hover-elevate active-elevate-2 cursor-pointer transition-all border-border/50" 
                        data-testid={`card-blog-${blog.id}`}
                      >
                        {blog.featuredImage ? (
                          <div className="relative aspect-[16/9] overflow-hidden bg-muted">
                            <img
                              src={blog.featuredImage}
                              alt={blog.title}
                              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                              data-testid={`img-blog-featured-${blog.id}`}
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                          </div>
                        ) : (
                          <div className="aspect-[16/9] bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center">
                            <div className="text-4xl font-bold text-primary/20">
                              {blog.title.charAt(0)}
                            </div>
                          </div>
                        )}
                        
                        <CardHeader className="space-y-4">
                          {/* Categories */}
                          <div className="flex flex-wrap gap-2">
                            {blog.categories.slice(0, 2).map((category) => (
                              <Badge 
                                key={category.id} 
                                variant="secondary" 
                                className="text-xs"
                                data-testid={`badge-category-${category.slug}`}
                              >
                                {category.name}
                              </Badge>
                            ))}
                          </div>

                          {/* Title */}
                          <CardTitle 
                            className="text-xl leading-tight line-clamp-2 group-hover:text-primary transition-colors" 
                            data-testid={`text-blog-title-${blog.id}`}
                          >
                            {blog.title}
                          </CardTitle>

                          {/* Excerpt */}
                          <p 
                            className="text-muted-foreground text-sm leading-relaxed line-clamp-3" 
                            data-testid={`text-blog-excerpt-${blog.id}`}
                          >
                            {blog.excerpt}
                          </p>

                          {/* Meta Info */}
                          <div className="flex items-center gap-4 pt-2 text-xs text-muted-foreground">
                            {blog.publishedAt && (
                              <div className="flex items-center gap-1.5">
                                <Calendar className="w-3.5 h-3.5" />
                                <span>{format(new Date(blog.publishedAt), "MMM d, yyyy")}</span>
                              </div>
                            )}
                            {blog.readingTime && (
                              <div className="flex items-center gap-1.5">
                                <Clock className="w-3.5 h-3.5" />
                                <span>{blog.readingTime} min</span>
                              </div>
                            )}
                          </div>
                        </CardHeader>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
