import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Helmet } from "react-helmet-async";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Building2, TrendingUp, Quote, ArrowLeft, Eye } from "lucide-react";
import MDEditor from "@uiw/react-md-editor";
import { apiRequest } from "@/lib/queryClient";

type CaseStudyItem = {
  id: string;
  type: string;
  status: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  featuredImage?: string;
  company?: string;
  industry?: string;
  metrics?: { metric: string; label: string }[];
  testimonial?: string;
  testimonialAuthor?: string;
  views: number;
  metaTitle?: string;
  metaDescription?: string;
  categories: { id: string; name: string; slug: string }[];
  tags: { id: string; name: string; slug: string }[];
};

export default function CaseStudyDetail() {
  const [, params] = useRoute("/case-studies/:slug");
  const slug = params?.slug;

  // Fetch the case study by slug
  const { data: caseStudy, isLoading } = useQuery<CaseStudyItem>({
    queryKey: [`/api/content/slug/${slug}`],
    enabled: !!slug,
  });

  // Fetch popular case studies for sidebar
  const { data: popularCaseStudies = [] } = useQuery<CaseStudyItem[]>({
    queryKey: [`/api/content/popular/case-study?limit=5`],
  });

  // Increment view count
  const incrementViewMutation = useMutation({
    mutationFn: async (contentId: string) => {
      await apiRequest("POST", `/api/content/${contentId}/view`);
    },
    onError: (error) => {
      console.error("Failed to increment view count:", error);
    },
  });

  useEffect(() => {
    if (caseStudy?.id && caseStudy.type === "case-study" && caseStudy.status === "published") {
      incrementViewMutation.mutate(caseStudy.id);
    }
  }, [caseStudy?.id]);

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <p className="text-xl text-muted-foreground">Loading...</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (!caseStudy || caseStudy.type !== "case-study" || caseStudy.status !== "published") {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-4xl font-bold mb-4">Case Study Not Found</h1>
          <p className="text-muted-foreground mb-8">The case study you're looking for doesn't exist or has been removed.</p>
          <Link href="/case-studies">
            <a className="text-primary hover:underline flex items-center gap-2 justify-center">
              <ArrowLeft className="w-4 h-4" />
              Back to Case Studies
            </a>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Helmet>
        <title>{caseStudy.metaTitle || caseStudy.title} | Your HS Expert</title>
        <meta 
          name="description" 
          content={caseStudy.metaDescription || caseStudy.excerpt || "Client success story from Your HS Expert."} 
        />
        <meta property="og:title" content={caseStudy.title} />
        <meta property="og:description" content={caseStudy.excerpt || ""} />
        <meta property="og:type" content="article" />
        {caseStudy.featuredImage && <meta property="og:image" content={caseStudy.featuredImage} />}
        <link rel="canonical" href={`${window.location.origin}/case-studies/${caseStudy.slug}`} />
      </Helmet>

      <Header />

      <article className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          <div className="max-w-7xl mx-auto">
            {/* Back to Case Studies */}
            <Link href="/case-studies">
              <div className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary cursor-pointer mb-8" data-testid="link-back-to-case-studies">
                <ArrowLeft className="w-4 h-4" />
                Back to Case Studies
              </div>
            </Link>

            <div className="grid lg:grid-cols-3 gap-8">
              {/* Main Content */}
              <div className="lg:col-span-2">
                {/* Featured Image */}
                {caseStudy.featuredImage && (
                  <div className="aspect-video overflow-hidden rounded-lg mb-8">
                    <img
                      src={caseStudy.featuredImage}
                      alt={caseStudy.title}
                      className="w-full h-full object-cover"
                      data-testid="img-case-study-featured"
                    />
                  </div>
                )}

                {/* Company & Industry */}
                <div className="flex items-center gap-4 mb-4 text-sm text-muted-foreground">
                  {caseStudy.company && (
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4" />
                      <span className="font-medium" data-testid="text-company">{caseStudy.company}</span>
                    </div>
                  )}
                  {caseStudy.industry && (
                    <>
                      <span>•</span>
                      <span data-testid="text-industry">{caseStudy.industry}</span>
                    </>
                  )}
                  <div className="flex items-center gap-2 ml-auto">
                    <Eye className="w-4 h-4" />
                    <span data-testid="text-case-study-views">{caseStudy.views} views</span>
                  </div>
                </div>

                {/* Categories */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {caseStudy.categories.map((category) => (
                    <Badge key={category.id} variant="secondary" data-testid={`badge-category-${category.slug}`}>
                      {category.name}
                    </Badge>
                  ))}
                </div>

                {/* Title */}
                <h1 className="text-4xl md:text-5xl font-bold mb-6" data-testid="text-case-study-title">
                  {caseStudy.title}
                </h1>

                {/* Metrics */}
                {caseStudy.metrics && caseStudy.metrics.length > 0 && (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
                    {caseStudy.metrics.map((metric, idx) => (
                      <Card key={idx}>
                        <CardContent className="p-4 text-center">
                          <div className="text-3xl font-bold text-primary mb-1" data-testid={`text-metric-value-${idx}`}>
                            {metric.metric}
                          </div>
                          <div className="text-sm text-muted-foreground" data-testid={`text-metric-label-${idx}`}>
                            {metric.label}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}

                <Separator className="mb-8" />

                {/* Content */}
                <div 
                  className="prose prose-lg max-w-none dark:prose-invert mb-8
                    [&_.wmde-markdown]:!bg-transparent [&_.wmde-markdown]:!text-foreground
                    [&_.wmde-markdown_h1]:!text-foreground [&_.wmde-markdown_h2]:!text-foreground [&_.wmde-markdown_h3]:!text-foreground
                    [&_.wmde-markdown_p]:!text-foreground/90 [&_.wmde-markdown_li]:!text-foreground/90" 
                  data-testid="content-case-study-body"
                >
                  <MDEditor.Markdown source={caseStudy.content} />
                </div>

                {/* Testimonial */}
                {caseStudy.testimonial && (
                  <Card className="bg-primary/5 border-primary/20">
                    <CardContent className="p-6">
                      <Quote className="w-8 h-8 text-primary mb-4" />
                      <blockquote className="text-lg italic mb-4" data-testid="text-testimonial">
                        "{caseStudy.testimonial}"
                      </blockquote>
                      {caseStudy.testimonialAuthor && (
                        <p className="font-semibold text-muted-foreground" data-testid="text-testimonial-author">
                          — {caseStudy.testimonialAuthor}
                        </p>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* Tags */}
                {caseStudy.tags.length > 0 && (
                  <div className="mt-12">
                    <Separator className="mb-6" />
                    <div className="flex flex-wrap gap-2">
                      {caseStudy.tags.map((tag) => (
                        <Badge key={tag.id} variant="outline" data-testid={`badge-tag-${tag.slug}`}>
                          #{tag.name}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Sidebar */}
              <div className="lg:col-span-1">
                <div className="sticky top-24 space-y-6">
                  {/* Popular Case Studies */}
                  {popularCaseStudies.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <TrendingUp className="w-5 h-5" />
                          More Success Stories
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {popularCaseStudies.map((story) => (
                          <Link key={story.id} href={`/case-studies/${story.slug}`}>
                            <div className="group cursor-pointer hover-elevate active-elevate-2 p-2 rounded-md -m-2" data-testid={`link-popular-case-study-${story.id}`}>
                              <h4 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors mb-1">
                                {story.title}
                              </h4>
                              {story.company && (
                                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                  <Building2 className="w-3 h-3" />
                                  <span>{story.company}</span>
                                </div>
                              )}
                            </div>
                          </Link>
                        ))}
                      </CardContent>
                    </Card>
                  )}

                  {/* CTA Card */}
                  <Card className="bg-primary/5 border-primary/20">
                    <CardContent className="p-6">
                      <h3 className="text-lg font-semibold mb-2">
                        Ready for similar results?
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        Let's discuss how we can transform your HubSpot
                      </p>
                      <Link 
                        href={`/book-call?utm_source=case_studies&utm_medium=content&utm_campaign=${caseStudy.slug}&utm_content=sidebar_cta`}
                      >
                        <Button className="w-full" data-testid="button-book-consultation">
                          Book a Call
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </article>

      <Footer />
    </div>
  );
}
