import { useState, useEffect, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, FileText, Folder, Tag, Image, Lock } from "lucide-react";
import MDEditor from "@uiw/react-md-editor";
import { ObjectUploader } from "@/components/ObjectUploader";
import type { UploadResult } from "@uppy/core";
import type { content, categories, tags, User } from "@shared/schema";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError, isForbiddenError } from "@/lib/authUtils";

type ContentItem = typeof content.$inferSelect;
type CategoryItem = typeof categories.$inferSelect;
type TagItem = typeof tags.$inferSelect;

type ContentWithRelations = ContentItem & {
  categories: CategoryItem[];
  tags: TagItem[];
};

export default function CMSAdmin() {
  const { toast } = useToast();
  const { user, isLoading, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState("content");
  const [editorMode, setEditorMode] = useState<"create" | "edit" | null>(null);
  const [selectedContent, setSelectedContent] = useState<ContentWithRelations | null>(null);
  const [filterType, setFilterType] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [lastSaved, setLastSaved] = useState<Date | null>(null);

  // Handle authentication redirects
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to access the CMS admin panel",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 1000);
    }
  }, [isAuthenticated, isLoading, toast]);

  // Form state
  const [title, setTitle] = useState("");
  const [slug, setSlug] = useState("");
  const [excerpt, setExcerpt] = useState("");
  const [content, setContent] = useState("");
  const [featuredImage, setFeaturedImage] = useState("");
  const [type, setType] = useState<"blog" | "case-study">("blog");
  const [status, setStatus] = useState<"draft" | "published">("draft");
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  // Queries
  const { data: allContent = [] } = useQuery<ContentWithRelations[]>({
    queryKey: ["/api/content", filterType, filterStatus],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filterType !== "all") params.append("type", filterType);
      if (filterStatus !== "all") params.append("status", filterStatus);
      
      const response = await fetch(`/api/content?${params}`);
      if (!response.ok) throw new Error("Failed to fetch content");
      return response.json();
    }
  });

  const { data: categories = [] } = useQuery<CategoryItem[]>({
    queryKey: ["/api/categories"]
  });

  const { data: tags = [] } = useQuery<TagItem[]>({
    queryKey: ["/api/tags"]
  });

  // Mutations
  const createContentMutation = useMutation({
    mutationFn: async (data: Record<string, any>) => {
      return apiRequest("POST", "/api/content", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/content"] });
      resetForm();
      toast({ title: "Content created successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error creating content", description: error.message, variant: "destructive" });
    }
  });

  const updateContentMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string, data: Record<string, any> }) => {
      return apiRequest("PATCH", `/api/content/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/content"] });
      resetForm();
      toast({ title: "Content updated successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error updating content", description: error.message, variant: "destructive" });
    }
  });

  const deleteContentMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/content/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/content"] });
      toast({ title: "Content deleted successfully" });
    }
  });

  // Auto-save to localStorage
  const saveDraft = useCallback(() => {
    const draft = {
      title,
      slug,
      excerpt,
      content,
      featuredImage,
      type,
      status,
      selectedCategories,
      selectedTags,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem("cms-draft", JSON.stringify(draft));
    setLastSaved(new Date());
  }, [title, slug, excerpt, content, featuredImage, type, status, selectedCategories, selectedTags]);

  // Restore draft from localStorage on mount
  useEffect(() => {
    const savedDraft = localStorage.getItem("cms-draft");
    if (savedDraft) {
      try {
        const draft = JSON.parse(savedDraft);
        if (draft.title || draft.content) {
          const shouldRestore = confirm("Found an unsaved draft. Would you like to restore it?");
          if (shouldRestore) {
            setTitle(draft.title || "");
            setSlug(draft.slug || "");
            setExcerpt(draft.excerpt || "");
            setContent(draft.content || "");
            setFeaturedImage(draft.featuredImage || "");
            setType(draft.type || "blog");
            setStatus(draft.status || "draft");
            setSelectedCategories(draft.selectedCategories || []);
            setSelectedTags(draft.selectedTags || []);
            setEditorMode("create");
            setLastSaved(draft.timestamp ? new Date(draft.timestamp) : null);
            toast({ title: "Draft restored" });
          } else {
            localStorage.removeItem("cms-draft");
          }
        }
      } catch (e) {
        console.error("Failed to restore draft:", e);
      }
    }
  }, []);

  // Auto-save interval
  useEffect(() => {
    if (editorMode && (title || content)) {
      const interval = setInterval(saveDraft, 30000); // Save every 30 seconds
      return () => clearInterval(interval);
    }
  }, [editorMode, title, content, saveDraft]);

  const resetForm = () => {
    setTitle("");
    setSlug("");
    setExcerpt("");
    setContent("");
    setFeaturedImage("");
    setType("blog");
    setStatus("draft");
    setSelectedCategories([]);
    setSelectedTags([]);
    setEditorMode(null);
    setSelectedContent(null);
    setLastSaved(null);
    localStorage.removeItem("cms-draft");
  };

  const handleEdit = (item: ContentWithRelations) => {
    setSelectedContent(item);
    setTitle(item.title);
    setSlug(item.slug);
    setExcerpt(item.excerpt || "");
    setContent(item.content || "");
    setFeaturedImage(item.featuredImage || "");
    setType(item.type as "blog" | "case-study");
    setStatus(item.status as "draft" | "published");
    setSelectedCategories(item.categories.map((c: CategoryItem) => c.id));
    setSelectedTags(item.tags.map((t: TagItem) => t.id));
    setEditorMode("edit");
  };

  const handleSubmit = () => {
    const data = {
      title,
      slug,
      excerpt,
      content,
      featuredImage: featuredImage || undefined,
      type,
      status,
      categoryIds: selectedCategories,
      tagIds: selectedTags
    };

    if (editorMode === "edit" && selectedContent) {
      updateContentMutation.mutate({ id: selectedContent.id, data });
    } else {
      createContentMutation.mutate(data);
    }
  };

  const handleImageUpload = async (): Promise<{ method: "PUT"; url: string }> => {
    const response = await fetch("/api/objects/upload", {
      method: "POST",
      headers: { "Content-Type": "application/json" }
    });
    
    if (!response.ok) {
      throw new Error("Failed to get upload URL");
    }
    
    const data = await response.json();
    return { method: "PUT", url: data.uploadURL };
  };

  const handleImageUploadComplete = async (result: UploadResult<Record<string, unknown>, Record<string, unknown>>) => {
    if (result.successful && result.successful.length > 0) {
      const uploadURL = result.successful[0].uploadURL as string;
      
      const response = await fetch("/api/content-images", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageURL: uploadURL })
      });
      
      if (response.ok) {
        const data = await response.json();
        setFeaturedImage(data.objectPath);
        toast({ title: "Image uploaded successfully" });
      }
    }
  };

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md p-8">
          <div className="text-center space-y-4">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto" />
            <p className="text-muted-foreground">Loading...</p>
          </div>
        </Card>
      </div>
    );
  }

  // Show access denied if not admin
  if (isAuthenticated && user && !(user as User).isAdmin) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <Card className="w-full max-w-md p-8">
          <div className="text-center space-y-6">
            <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto">
              <Lock className="w-8 h-8 text-destructive" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-bold">Access Denied</h2>
              <p className="text-muted-foreground">
                You don't have admin privileges to access the CMS. Please contact an administrator.
              </p>
            </div>
            <div className="flex gap-3 justify-center">
              <Button onClick={() => window.location.href = "/"} variant="outline" data-testid="button-home">
                Go to Homepage
              </Button>
              <Button onClick={() => window.location.href = "/api/logout"} data-testid="button-logout">
                Logout
              </Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-4xl font-bold" data-testid="text-admin-title">CMS Admin</h1>
            {user && (
              <Badge variant="outline" className="gap-2" data-testid="badge-user">
                <span className="text-xs">{(user as User).email || 'Admin User'}</span>
              </Badge>
            )}
          </div>
          <div className="flex gap-3">
            <Button 
              onClick={() => setEditorMode("create")} 
              data-testid="button-create-content"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Content
            </Button>
            <Button 
              onClick={() => window.location.href = "/api/logout"} 
              variant="outline"
              data-testid="button-logout-header"
            >
              Logout
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="content" data-testid="tab-content">
              <FileText className="w-4 h-4 mr-2" />
              Content
            </TabsTrigger>
            <TabsTrigger value="categories" data-testid="tab-categories">
              <Folder className="w-4 h-4 mr-2" />
              Categories
            </TabsTrigger>
            <TabsTrigger value="tags" data-testid="tab-tags">
              <Tag className="w-4 h-4 mr-2" />
              Tags
            </TabsTrigger>
          </TabsList>

          <TabsContent value="content" className="space-y-4">
            {editorMode ? (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{editorMode === "create" ? "Create New Content" : "Edit Content"}</CardTitle>
                    {lastSaved && (
                      <span className="text-sm text-muted-foreground">
                        Last saved: {lastSaved.toLocaleTimeString()}
                      </span>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="title">Title</Label>
                      <Input 
                        id="title" 
                        value={title} 
                        onChange={(e) => setTitle(e.target.value)}
                        data-testid="input-title"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="slug">Slug</Label>
                      <Input 
                        id="slug" 
                        value={slug} 
                        onChange={(e) => setSlug(e.target.value)}
                        data-testid="input-slug"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="excerpt">Excerpt</Label>
                    <Textarea 
                      id="excerpt" 
                      value={excerpt} 
                      onChange={(e) => setExcerpt(e.target.value)}
                      rows={3}
                      data-testid="input-excerpt"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Content (Markdown)</Label>
                    <div data-color-mode="light">
                      <MDEditor
                        value={content}
                        onChange={(val) => setContent(val || "")}
                        height={400}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="type">Type</Label>
                      <Select value={type} onValueChange={(v: any) => setType(v)}>
                        <SelectTrigger data-testid="select-type">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="blog">Blog</SelectItem>
                          <SelectItem value="case-study">Case Study</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="status">Status</Label>
                      <Select value={status} onValueChange={(v: any) => setStatus(v)}>
                        <SelectTrigger data-testid="select-status">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="draft">Draft</SelectItem>
                          <SelectItem value="published">Published</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Featured Image</Label>
                      <ObjectUploader
                        maxNumberOfFiles={1}
                        maxFileSize={5242880}
                        onGetUploadParameters={handleImageUpload}
                        onComplete={handleImageUploadComplete}
                      >
                        <Image className="w-4 h-4 mr-2" />
                        Upload Image
                      </ObjectUploader>
                      {featuredImage && (
                        <p className="text-sm text-muted-foreground mt-1">Image uploaded</p>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button onClick={handleSubmit} data-testid="button-save-content">
                      {editorMode === "create" ? "Create" : "Update"}
                    </Button>
                    <Button variant="outline" onClick={resetForm} data-testid="button-cancel">
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <>
                <div className="flex gap-4">
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-48" data-testid="filter-type">
                      <SelectValue placeholder="Filter by type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="blog">Blog</SelectItem>
                      <SelectItem value="case-study">Case Study</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-48" data-testid="filter-status">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="published">Published</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-4">
                  {allContent.map((item) => (
                    <Card key={item.id} className="hover-elevate" data-testid={`card-content-${item.id}`}>
                      <CardContent className="p-4 flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold">{item.title}</h3>
                            <Badge variant={item.status === "published" ? "default" : "secondary"}>
                              {item.status}
                            </Badge>
                            <Badge variant="outline">{item.type}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{item.excerpt}</p>
                          <div className="flex gap-2 mt-2">
                            {item.categories.map((cat: CategoryItem) => (
                              <Badge key={cat.id} variant="secondary" className="text-xs">
                                {cat.name}
                              </Badge>
                            ))}
                            {item.tags.map((tag: TagItem) => (
                              <Badge key={tag.id} variant="outline" className="text-xs">
                                {tag.name}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleEdit(item)}
                            data-testid={`button-edit-${item.id}`}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => deleteContentMutation.mutate(item.id)}
                            data-testid={`button-delete-${item.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </>
            )}
          </TabsContent>

          <TabsContent value="categories">
            <Card>
              <CardHeader>
                <CardTitle>Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">Category management coming soon...</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tags">
            <Card>
              <CardHeader>
                <CardTitle>Tags</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">Tag management coming soon...</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
