import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, CheckCircle2, HeadphonesIcon, Users, Wrench, Shield, Clock, Sparkles, LifeBuoy, UserCog } from "lucide-react";
import { SiHubspot } from "react-icons/si";
import { Link } from "wouter";
import { Helmet } from "react-helmet-async";

export default function Admin() {
  const features = [
    {
      icon: HeadphonesIcon,
      title: "Dedicated Support",
      description: "Direct access to HubSpot experts for quick resolution of any issues or questions."
    },
    {
      icon: UserCog,
      title: "User Management",
      description: "Manage user permissions, onboarding, and training for your growing team."
    },
    {
      icon: Wrench,
      title: "Technical Troubleshooting",
      description: "Expert diagnosis and resolution of technical issues, integrations, and customizations."
    },
    {
      icon: Sparkles,
      title: "Regular Maintenance",
      description: "Proactive portal health checks, updates, and optimizations to keep everything running smoothly."
    }
  ];

  const process = [
    {
      step: 1,
      title: "Admin Onboarding",
      description: "We learn your business, processes, and HubSpot setup to provide tailored support.",
      duration: "1 week"
    },
    {
      step: 2,
      title: "Support Channel Setup",
      description: "Establish communication channels (Slack, email, tickets) for seamless support requests.",
      duration: "1 day"
    },
    {
      step: 3,
      title: "Ongoing Support",
      description: "Handle day-to-day issues, questions, and requests with fast response times.",
      duration: "Ongoing"
    },
    {
      step: 4,
      title: "Monthly Health Checks",
      description: "Proactive portal reviews to identify and resolve issues before they impact your team.",
      duration: "Monthly"
    },
    {
      step: 5,
      title: "Updates & Training",
      description: "Keep your team informed of new features and provide training as your needs evolve.",
      duration: "Ongoing"
    }
  ];

  const results = [
    { metric: "<12hr", label: "Average Response Time" },
    { metric: "98%", label: "Data Integrity" },
    { metric: "95%+", label: "Client Retention" }
  ];

  return (
    <div className="min-h-screen">
      <Helmet>
        <title>HubSpot Admin & Support Services | Your HS Expert</title>
        <meta 
          name="description" 
          content="Expert HubSpot admin and support services. Dedicated HubSpot support, user management, technical troubleshooting, and ongoing maintenance with <2hr response time." 
        />
        <meta property="og:title" content="HubSpot Admin & Support Services | Your HS Expert" />
        <meta 
          property="og:description" 
          content="Reliable HubSpot admin services with dedicated support, user management, troubleshooting, and proactive maintenance. Get 99.9% uptime guarantee." 
        />
        <meta property="og:type" content="website" />
        <meta name="keywords" content="HubSpot admin, HubSpot support, technical support, user management, HubSpot maintenance, CRM admin, ongoing support" />
        <link rel="canonical" href="https://hs-solutions-partner-mason180.replit.app/services/admin" />
      </Helmet>
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-gradient-to-b from-background via-muted/20 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 mb-12">
            <Button variant="ghost" size="sm" data-testid="button-back" asChild>
              <Link href="/">← Back to Home</Link>
            </Button>
            <Badge className="bg-primary/10 text-primary border-primary/20" data-testid="badge-service">
              <LifeBuoy className="w-3 h-3 mr-1" />
              HubSpot Admin & Support
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight leading-tight">
              Your Dedicated <span className="text-primary">HubSpot Admin</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Expert HubSpot support and administration so you can focus on growing your business. 
              We handle the technical details while you focus on results.
            </p>
            <div className="flex justify-center gap-4">
              <Button size="lg" asChild data-testid="button-book-call">
                <a href="/book-call?utm_source=service_page&utm_medium=hero&utm_campaign=admin_support">
                  Book a Call <ArrowRight className="ml-2 h-5 w-5" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild data-testid="button-view-case-studies">
                <a href="/#case-studies">View Case Studies</a>
              </Button>
            </div>
          </div>

          {/* Results */}
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {results.map((result) => (
              <Card key={result.label} className="text-center p-6" data-testid={`card-result-${result.label.toLowerCase().replace(/\s+/g, '-')}`}>
                <div className="text-4xl font-bold text-primary mb-2">{result.metric}</div>
                <div className="text-sm text-muted-foreground">{result.label}</div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold tracking-tight">Admin Services</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Comprehensive HubSpot administration and support to keep your portal running at peak performance
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature) => (
              <Card key={feature.title} className="text-center p-6 hover-elevate transition-all" data-testid={`card-feature-${feature.title.toLowerCase().replace(/\s+/g, '-')}`}>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Timeline */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold tracking-tight">How It Works</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              A proactive approach to HubSpot administration and support
            </p>
          </div>

          <div className="space-y-6">
            {process.map((step) => (
              <Card key={step.step} className="p-6 hover-elevate transition-all" data-testid={`card-process-${step.step}`}>
                <div className="flex items-start gap-6">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold">
                    {step.step}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-semibold">{step.title}</h3>
                      <Badge variant="secondary" className="text-xs">
                        {step.duration}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold tracking-tight">Pricing Plans</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Flexible admin and support packages designed to fit your needs
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Hourly Consulting */}
            <Card className="p-8 flex flex-col hover-elevate transition-all" data-testid="pricing-hourly">
              <div className="mb-6">
                <h3 className="text-2xl font-bold mb-2">Hourly Consulting</h3>
                <div className="text-3xl font-bold text-primary">$200<span className="text-lg font-normal text-foreground"> / hr</span></div>
              </div>
              <p className="text-muted-foreground mb-6">
                Perfect for businesses that require on-demand support or quick consultations. Ideal for those needing expert advice or guidance in a short time frame.
              </p>
              <div className="space-y-3 mb-8 flex-1">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">HubSpot Setup & Optimization</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Automation Strategy & Custom Development</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Data Migration & Cleanup</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Pipeline Strategy & Architecture</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Reporting & Dashboard Solutions</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Integration Services</span>
                </div>
              </div>
              <Button className="w-full" size="lg" asChild data-testid="button-pricing-hourly">
                <a href="https://meetings.hubspot.com/yourhubspotexpert/intro-call">
                  Schedule a Call <ArrowRight className="ml-2 h-5 w-5" />
                </a>
              </Button>
            </Card>

            {/* Growth Support */}
            <Card className="p-8 flex flex-col hover-elevate transition-all border-primary/50" data-testid="pricing-growth">
              <div className="mb-6">
                <h3 className="text-2xl font-bold mb-2">Admin Support</h3>
                <div className="text-3xl font-bold text-primary">$2,250<span className="text-lg font-normal text-foreground"> / month</span></div>
              </div>
              <p className="text-muted-foreground mb-6">
                Designed for teams eager to accelerate their growth, this plan offers direct access to HubSpot experts with faster turnaround times and proactive support. Minimum 3-month commitment.
              </p>
              <div className="space-y-3 mb-8 flex-1">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Up to 15 hours of HubSpot support/month</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Email responses within 24 hours</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Access to detailed Loom walkthroughs for key updates</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Weekly check-ins to track progress</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Hourly overages billed at $140/hr</span>
                </div>
              </div>
              <Button className="w-full" size="lg" asChild data-testid="button-pricing-growth">
                <a href="https://meetings.hubspot.com/yourhubspotexpert/intro-call">
                  Schedule a Call <ArrowRight className="ml-2 h-5 w-5" />
                </a>
              </Button>
            </Card>

            {/* Priority Growth Partnership */}
            <Card className="p-8 flex flex-col hover-elevate transition-all" data-testid="pricing-priority">
              <div className="mb-6">
                <h3 className="text-2xl font-bold mb-2">HubSpot Partnership</h3>
                <div className="text-3xl font-bold text-primary">$3,750<span className="text-lg font-normal text-foreground"> / month</span></div>
              </div>
              <p className="text-muted-foreground mb-6">
                Ideal for teams looking to scale fast and achieve sustainable growth with a dedicated partner for HubSpot. Get rapid response times, strategic roadmaps, and a deeper focus on your business. Minimum 3-month commitment.
              </p>
              <div className="space-y-3 mb-8 flex-1">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Up to 25 hours of HubSpot support/month</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Same-day response guarantee</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Quarterly roadmap & strategic planning sessions</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Continuous process optimization recommendations</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Weekly check-ins for ongoing support</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-sm">Hourly overages billed at $130/hr</span>
                </div>
              </div>
              <Button className="w-full" size="lg" asChild data-testid="button-pricing-priority">
                <a href="https://meetings.hubspot.com/yourhubspotexpert/intro-call">
                  Schedule a Call <ArrowRight className="ml-2 h-5 w-5" />
                </a>
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Credibility Section */}
      <section className="py-16 bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-center gap-8">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                <SiHubspot className="w-8 h-8 text-primary" />
              </div>
              <div>
                <div className="font-bold text-lg">Certified HubSpot Partner</div>
                <div className="text-sm text-muted-foreground">Expert Administration</div>
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">&lt;12hr</div>
              <div className="text-sm text-muted-foreground">Response Time</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">82%</div>
              <div className="text-sm text-muted-foreground">Workflow Efficiency</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">95%+</div>
              <div className="text-sm text-muted-foreground">Client Retention</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold tracking-tight mb-6">
            Need Reliable HubSpot Support?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Let's discuss your support needs and create a custom admin plan.
          </p>
          <Button size="lg" asChild data-testid="button-cta-book-call">
            <a href="https://meetings.hubspot.com/yourhubspotexpert/intro-call">
              Schedule a Consultation <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
        </div>
      </section>
    </div>
  );
}
