import Header from "@/components/Header";
import Hero from "@/components/Hero";
import TrustedBy from "@/components/TrustedBy";
import Services from "@/components/Services";
import About from "@/components/About";
import CaseStudies from "@/components/CaseStudies";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import { Helmet } from "react-helmet-async";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Helmet>
        <title>Your HS Expert - HubSpot Solutions Partner | Implementation & Migration Services</title>
        <meta 
          name="description" 
          content="Transform your business with expert HubSpot implementation, migration, and consulting services. Your HS Expert is a certified HubSpot Solutions Partner delivering measurable results with 200+ successful projects." 
        />
        <meta property="og:title" content="Your HS Expert - HubSpot Solutions Partner" />
        <meta 
          property="og:description" 
          content="Expert HubSpot implementation, migration, and consulting services that drive real business results. Certified partner with proven track record." 
        />
        <meta property="og:type" content="website" />
        <meta name="keywords" content="HubSpot partner, HubSpot solutions, HubSpot implementation, HubSpot migration, HubSpot consulting, CRM setup, marketing automation, sales enablement" />
        <link rel="canonical" href="https://hs-solutions-partner-mason180.replit.app/" />
      </Helmet>
      
      <Header />
      <Hero />
      <TrustedBy />
      <Services />
      <About />
      <CaseStudies />
      <Contact />
      <Footer />
    </div>
  );
}
