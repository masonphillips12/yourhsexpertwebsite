import { useEffect } from "react";
import { Helmet } from "react-helmet-async";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Users, TrendingUp, Award, Star, Shield, Clock } from "lucide-react";
import { motion } from "framer-motion";

export default function BookCall() {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://static.hsappstatic.net/MeetingsEmbed/ex/MeetingsEmbedCode.js';
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const stats = [
    { value: "200+", label: "Clients Served", icon: Users },
    { value: "98%", label: "Client Satisfaction", icon: Star },
    { value: "15+", label: "Years Experience", icon: Award },
    { value: "24/7", label: "Support Available", icon: Shield },
  ];

  const certifications = [
    "Certified Solutions Partner",
    "CMS Implementation Certified",
    "Marketing Hub Certified",
    "Sales Hub Certified",
  ];

  const testimonials = [
    {
      quote: "Working with Your HS Expert transformed our lead generation. The automated scoring and routing alone saved our team 10+ hours per week.",
      author: "John Smith",
      title: "VP of Marketing",
      company: "Tosi - Industrial Technology",
    },
    {
      quote: "The automated onboarding system has been a game-changer. Our customers are happier and our team is more productive.",
      author: "Emily Rodriguez",
      title: "Head of Customer Success",
      company: "CloudFlow - SaaS",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Book a Call - Your Trusted HubSpot Solutions Partner | Your HS Expert</title>
        <meta 
          name="description" 
          content="Schedule a free consultation with our certified HubSpot experts. Get personalized guidance on implementation, migration, and optimization." 
        />
        <meta property="og:title" content="Book a Call - Your Trusted HubSpot Solutions Partner" />
        <meta property="og:description" content="Schedule a free consultation with our certified HubSpot experts." />
        <meta property="og:type" content="website" />
        <link rel="canonical" href={`${window.location.origin}/book-call`} />
      </Helmet>

      <Header />

      {/* Trust Hero Section */}
      <section className="relative py-16 md:py-20 overflow-hidden border-b">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-background" />
        <div className="container mx-auto px-4 relative">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* HubSpot Partner Badge */}
              <Badge className="bg-primary/10 text-primary border-primary/20 mb-6 text-base px-4 py-2">
                <Award className="w-4 h-4 mr-2" />
                Certified HubSpot Solutions Partner
              </Badge>

              {/* Title */}
              <h1 className="text-4xl md:text-5xl font-bold mb-4 tracking-tight">
                Book Your Free Discovery Call
              </h1>
              
              {/* Subtitle */}
              <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-8">
                Schedule a 30-minute call with our HubSpot experts to explore how we can help you maximize your investment
              </p>
            </motion.div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.1 + index * 0.05 }}
                >
                  <Card className="border-border/50">
                    <CardContent className="p-4 text-center">
                      <stat.icon className="w-6 h-6 text-primary mx-auto mb-2" />
                      <div className="text-2xl md:text-3xl font-bold text-primary mb-1">
                        {stat.value}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {stat.label}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Certifications */}
            <div className="flex flex-wrap justify-center gap-2">
              {certifications.map((cert, index) => (
                <Badge 
                  key={index} 
                  variant="secondary" 
                  className="text-xs px-3 py-1"
                >
                  <CheckCircle2 className="w-3 h-3 mr-1.5 text-primary" />
                  {cert}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Calendar Section */}
      <section className="py-16 md:py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Calendar */}
              <motion.div
                className="lg:col-span-2"
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <Card className="border-border/50 shadow-lg">
                  <CardContent className="p-6">
                    <div 
                      className="meetings-iframe-container" 
                      data-src="https://meetings.hubspot.com/yourhubspotexpert/intro-call?embed=true"
                      data-testid="hubspot-calendar-embed"
                    />
                  </CardContent>
                </Card>
              </motion.div>

              {/* Sidebar Info */}
              <motion.div
                className="space-y-6"
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                {/* What to Expect */}
                <Card className="bg-primary text-primary-foreground border-primary">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-4">
                      <Clock className="w-5 h-5" />
                      <h4 className="text-xl font-semibold">What to Expect</h4>
                    </div>
                    <ul className="space-y-3 text-primary-foreground/90 text-sm">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>30-minute strategy session with a HubSpot expert</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Review of your current setup and pain points</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Customized recommendations for your business</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>No pressure - we'll see if we're a good fit</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>

                {/* Trust Badges */}
                <Card className="border-border/50">
                  <CardContent className="p-6">
                    <h4 className="font-semibold mb-4">Why Choose Us?</h4>
                    <div className="space-y-3 text-sm">
                      <div className="flex items-center gap-2">
                        <Shield className="w-4 h-4 text-primary flex-shrink-0" />
                        <span className="text-muted-foreground">Certified Solutions Partner</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-primary flex-shrink-0" />
                        <span className="text-muted-foreground">3x Average ROI Increase</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-primary flex-shrink-0" />
                        <span className="text-muted-foreground">200+ Successful Projects</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Award className="w-4 h-4 text-primary flex-shrink-0" />
                        <span className="text-muted-foreground">15+ Years Experience</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="py-16 md:py-20 bg-muted/30 border-t">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            {/* Section Header */}
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-3">
                Trusted by Growing Businesses
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                See what our clients say about working with us
              </p>
            </div>

            {/* Testimonials Grid */}
            <div className="grid md:grid-cols-2 gap-8 mb-12">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="h-full border-border/50">
                    <CardContent className="p-8">
                      {/* Stars */}
                      <div className="flex gap-1 mb-4">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                        ))}
                      </div>

                      {/* Quote */}
                      <blockquote className="text-base mb-6 leading-relaxed">
                        "{testimonial.quote}"
                      </blockquote>

                      {/* Author */}
                      <div className="border-t pt-4">
                        <div className="font-semibold text-sm">{testimonial.author}</div>
                        <div className="text-sm text-muted-foreground">{testimonial.title}</div>
                        <div className="text-sm text-muted-foreground">{testimonial.company}</div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Results Highlights */}
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="text-center border-border/50">
                <CardContent className="p-6">
                  <Users className="w-10 h-10 text-primary mx-auto mb-3" />
                  <div className="text-3xl font-bold mb-2">200%</div>
                  <div className="text-sm text-muted-foreground">
                    Average Lead Quality Increase
                  </div>
                </CardContent>
              </Card>

              <Card className="text-center border-border/50">
                <CardContent className="p-6">
                  <TrendingUp className="w-10 h-10 text-primary mx-auto mb-3" />
                  <div className="text-3xl font-bold mb-2">60%</div>
                  <div className="text-sm text-muted-foreground">
                    Faster Customer Onboarding
                  </div>
                </CardContent>
              </Card>

              <Card className="text-center border-border/50">
                <CardContent className="p-6">
                  <Award className="w-10 h-10 text-primary mx-auto mb-3" />
                  <div className="text-3xl font-bold mb-2">98%</div>
                  <div className="text-sm text-muted-foreground">
                    Client Satisfaction Rate
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
