import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, CheckCircle2, Palette, Code, Smartphone, Search, Globe, Zap, Layout, FileCode } from "lucide-react";
import { SiHubspot } from "react-icons/si";
import { Link } from "wouter";
import { Helmet } from "react-helmet-async";

export default function CMSDevelopment() {
  const features = [
    {
      icon: Palette,
      title: "Custom Design",
      description: "Beautiful, brand-aligned designs that convert visitors into customers."
    },
    {
      icon: Code,
      title: "HubSpot CMS Development",
      description: "Custom modules, templates, and themes built specifically for HubSpot CMS."
    },
    {
      icon: Smartphone,
      title: "Responsive Development",
      description: "Mobile-first designs that work flawlessly on all devices and screen sizes."
    },
    {
      icon: Search,
      title: "SEO Optimization",
      description: "Built-in SEO best practices to help your content rank higher in search results."
    }
  ];

  const process = [
    {
      step: 1,
      title: "Discovery & Strategy",
      description: "We understand your brand, goals, and target audience to create a comprehensive design strategy.",
      duration: "1 week"
    },
    {
      step: 2,
      title: "Design & Wireframing",
      description: "Create custom designs and wireframes that align with your brand and conversion goals.",
      duration: "2 weeks"
    },
    {
      step: 3,
      title: "Development",
      description: "Build custom HubSpot CMS modules, templates, and themes with clean, maintainable code.",
      duration: "3-4 weeks"
    },
    {
      step: 4,
      title: "Content Migration",
      description: "Seamlessly migrate your existing content while preserving SEO value.",
      duration: "1 week"
    },
    {
      step: 5,
      title: "Testing & Launch",
      description: "Thorough QA testing across devices and browsers before going live.",
      duration: "1 week"
    }
  ];

  const results = [
    { metric: "145%", label: "Increased Conversion Rate" },
    { metric: "35%", label: "Decreased Bounce Rate" },
    { metric: "3x", label: "Landing Page ROI" }
  ];

  return (
    <div className="min-h-screen">
      <Helmet>
        <title>HubSpot CMS Design & Development Services | Your HS Expert</title>
        <meta 
          name="description" 
          content="Professional HubSpot CMS website design and development services. Custom templates, responsive design, SEO optimization, and content migration. Get 145% higher conversion rates." 
        />
        <meta property="og:title" content="HubSpot CMS Design & Development Services | Your HS Expert" />
        <meta 
          property="og:description" 
          content="Expert HubSpot CMS development with custom modules, responsive design, and SEO optimization. Transform your website into a conversion machine." 
        />
        <meta property="og:type" content="website" />
        <meta name="keywords" content="HubSpot CMS, website design, HubSpot development, custom modules, responsive design, landing pages, HubSpot templates, CMS development" />
        <link rel="canonical" href="https://hs-solutions-partner-mason180.replit.app/services/cms-development" />
      </Helmet>
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-gradient-to-b from-background via-muted/20 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6 mb-12">
            <Button variant="ghost" size="sm" data-testid="button-back" asChild>
              <Link href="/">← Back to Home</Link>
            </Button>
            <Badge className="bg-primary/10 text-primary border-primary/20" data-testid="badge-service">
              <Layout className="w-3 h-3 mr-1" />
              CMS Design & Development
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight leading-tight">
              HubSpot CMS <span className="text-primary">Design & Development</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Custom HubSpot CMS websites that combine stunning design with powerful functionality. 
              We build conversion-focused sites that drive real business results.
            </p>
            <div className="flex justify-center gap-4">
              <Button size="lg" asChild data-testid="button-book-call">
                <a href="/book-call?utm_source=service_page&utm_medium=hero&utm_campaign=cms_development">
                  Book a Call <ArrowRight className="ml-2 h-5 w-5" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild data-testid="button-view-case-studies">
                <a href="/#case-studies">View Case Studies</a>
              </Button>
            </div>
          </div>

          {/* Results */}
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {results.map((result) => (
              <Card key={result.label} className="text-center p-6" data-testid={`card-result-${result.label.toLowerCase().replace(/\s+/g, '-')}`}>
                <div className="text-4xl font-bold text-primary mb-2">{result.metric}</div>
                <div className="text-sm text-muted-foreground">{result.label}</div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold tracking-tight">What's Included</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Comprehensive CMS development services tailored to your business needs
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature) => (
              <Card key={feature.title} className="text-center p-6 hover-elevate transition-all" data-testid={`card-feature-${feature.title.toLowerCase().replace(/\s+/g, '-')}`}>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Timeline */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold tracking-tight">Our Process</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              A proven approach to delivering high-quality HubSpot CMS websites
            </p>
          </div>

          <div className="space-y-6">
            {process.map((step) => (
              <Card key={step.step} className="p-6 hover-elevate transition-all" data-testid={`card-process-${step.step}`}>
                <div className="flex items-start gap-6">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold">
                    {step.step}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-semibold">{step.title}</h3>
                      <Badge variant="secondary" className="text-xs">
                        {step.duration}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Credibility Section */}
      <section className="py-16 bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-center gap-8">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                <SiHubspot className="w-8 h-8 text-primary" />
              </div>
              <div>
                <div className="font-bold text-lg">Certified HubSpot Partner</div>
                <div className="text-sm text-muted-foreground">Expert CMS Development</div>
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">50+</div>
              <div className="text-sm text-muted-foreground">Websites Built</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">100%</div>
              <div className="text-sm text-muted-foreground">Client Satisfaction</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">145%</div>
              <div className="text-sm text-muted-foreground">Avg. Conversion Increase</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold tracking-tight mb-6">
            Ready to Build Your HubSpot Website?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Let's discuss your project and create a custom solution that drives results.
          </p>
          <Button size="lg" asChild data-testid="button-cta-book-call">
            <a href="https://meetings.hubspot.com/yourhubspotexpert/intro-call">
              Schedule a Free Consultation <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
        </div>
      </section>
    </div>
  );
}
