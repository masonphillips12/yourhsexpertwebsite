import bwwLogo from "@assets/Buffalo-Wild-Wings-Logo_1759976969095.png";
import elvLogo from "@assets/ELV_1759977046678.png";
import zendropLogo from "@assets/Untitled design_1760052622660.png";
import breedrLogo from "@assets/Untitled design (2)_1760052730374.png";
import getimageLogo from "@assets/GetImage_1759977452202.webp";
import ziperaseLogo from "@assets/ziperase_logo_Light_1759977543350.png";
import advisorfinderLogo from "@assets/Untitled design (1)_1760052679958.png";
import vivLogo from "@assets/Untitled design (3)_1760052769705.png";
import { motion } from "framer-motion";

const clientLogos = [
  { name: "Buffalo Wild Wings", logo: bwwLogo },
  { name: "Evolve Health", logo: elvLogo },
  { name: "Zendrop", logo: zendropLogo },
  { name: "Breedr", logo: breedrLogo },
  { name: "GetImage", logo: getimageLogo },
  { name: "Ziperase", logo: ziperaseLogo },
  { name: "AdvisorFinder", logo: advisorfinderLogo },
  { name: "Viv", logo: vivLogo },
];

export default function TrustedBy() {
  return (
    <section className="py-20 md:py-24 relative overflow-hidden bg-background">
      <div className="absolute inset-0 opacity-20 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="flex justify-center lg:justify-start">
            <div className="border-2 border-primary/30 rounded-lg p-12 text-center max-w-sm backdrop-blur-sm">
              <div className="text-6xl md:text-7xl font-bold text-primary mb-4">80+%</div>
              <p className="text-base text-muted-foreground leading-relaxed">
                of clients hire us for a second project or ongoing work
              </p>
            </div>
          </div>

          <div>
            <div className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-8 text-center lg:text-left">
              Trusted By
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-12 gap-y-10 items-center">
              {clientLogos.map((client, i) => (
                <motion.div
                  key={client.name}
                  className="flex items-center justify-center grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all duration-300"
                  data-testid={`logo-${client.name.toLowerCase().replace(/\s+/g, '-')}`}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 0.6, y: 0 }}
                  whileHover={{ opacity: 1, scale: 1.1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: i * 0.05 }}
                >
                  <img 
                    src={client.logo} 
                    alt={client.name}
                    className="h-16 w-16 object-contain"
                  />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
