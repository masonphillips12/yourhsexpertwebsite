import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { SiHubspot, SiLinkedin, SiX } from "react-icons/si";
import { useState } from "react";
import logo from "@assets/targeted_element_1760052883299.png";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Newsletter subscription:", email);
    setSubscribed(true);
    setEmail("");
    setTimeout(() => setSubscribed(false), 3000);
  };

  const footerLinks = {
    Services: [
      { label: "HubSpot Onboarding/Migration", href: "#services" },
      { label: "HubSpot CMS Design & Development", href: "#services" },
      { label: "HubSpot Optimization", href: "#services" },
      { label: "HubSpot Admin", href: "#services" },
    ],
    Company: [
      { label: "About Us", href: "#about" },
      { label: "Case Studies", href: "#case-studies" },
      { label: "Certifications", href: "#about" },
      { label: "Contact", href: "#contact" },
    ],
    Resources: [
      { label: "Blog", href: "#" },
      { label: "HubSpot Tips", href: "#" },
      { label: "Free Audit", href: "#contact" },
      { label: "Documentation", href: "#" },
    ],
  };

  return (
    <footer className="bg-card/50 border-t">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div className="space-y-6">
            <div className="flex items-center">
              <img src={logo} alt="Your HS Expert" className="h-8 w-auto" />
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Your trusted HubSpot Solutions Partner delivering expert implementation, migration, and consulting services.
            </p>
            <div className="flex items-center space-x-2">
              <Badge variant="secondary" className="text-xs">
                <SiHubspot className="mr-1 h-3 w-3" />
                Official Solutions Partner
              </Badge>
            </div>
          </div>

          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="font-semibold mb-4">{category}</h3>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                      data-testid={`link-footer-${link.label.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t pt-12 mb-12">
          <div className="max-w-md">
            <h3 className="font-semibold mb-3">Subscribe to our newsletter</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Get HubSpot tips, insights, and updates delivered to your inbox.
            </p>
            <form onSubmit={handleSubscribe} className="flex gap-2">
              <Input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                data-testid="input-newsletter"
                className="flex-1"
              />
              <Button type="submit" data-testid="button-subscribe">
                {subscribed ? "Subscribed!" : "Subscribe"}
              </Button>
            </form>
          </div>
        </div>

        <div className="border-t pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Your HS Expert. All rights reserved.
            </p>
            <div className="flex items-center space-x-6">
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="link-linkedin"
              >
                <SiLinkedin className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="link-twitter"
              >
                <SiX className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="link-hubspot"
              >
                <SiHubspot className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
