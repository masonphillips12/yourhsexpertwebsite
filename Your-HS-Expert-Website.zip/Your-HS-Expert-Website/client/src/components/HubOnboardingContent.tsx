import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

const hubContent = {
  marketing: {
    title: "Marketing Hub Onboarding",
    description: "Email, Ads & Lead Generation",
    sections: [
      {
        title: "Account Setup",
        items: [
          "Set up HubSpot account and connect with your email domain",
          "Configure global settings (timezone, language, business information, and logo)",
          "Install HubSpot tracking code on your website",
          "Verify and set up connected social media accounts"
        ]
      },
      {
        title: "Contact Management",
        items: [
          "Define and create custom properties for leads, contacts, and companies",
          "Set up segmentation using lists (static and active)",
          "Import contact data with proper mapping and deduplication"
        ]
      },
      {
        title: "Forms & Landing Pages",
        items: [
          "Create and configure forms for lead capture",
          "Design and launch landing pages using templates",
          "Set up thank-you pages and form confirmation emails"
        ]
      },
      {
        title: "Email Marketing Setup",
        items: [
          "Set up email templates and design",
          "Create email lists for targeted email campaigns",
          "Set up email subscription preferences and GDPR compliance",
          "Test email deliverability and performance"
        ]
      },
      {
        title: "Automation & Workflows",
        items: [
          "Set up lead nurturing workflows (welcome series, lead scoring)",
          "Configure workflow triggers (form submissions, email opens, etc.)",
          "Automate internal notifications for lead qualification"
        ]
      },
      {
        title: "Reporting & Analytics",
        items: [
          "Configure dashboards for email performance, website traffic, and lead generation",
          "Set up goal tracking (form submissions, email clicks, etc.)",
          "Enable tracking of important marketing metrics (MQLs, conversions)"
        ]
      },
      {
        title: "SEO & Content Strategy",
        items: [
          "Set up blog, categories, and blog post templates",
          "Configure SEO tools and keyword tracking",
          "Set up content strategy tools for topic clusters and pillar pages"
        ]
      }
    ]
  },
  sales: {
    title: "Sales Hub Onboarding",
    description: "CRM, Sales Automation & Pipeline",
    sections: [
      {
        title: "Account Setup",
        items: [
          "Configure user roles and permissions for sales reps and admins",
          "Set up pipelines and stages according to your sales process",
          "Set up email integration (Gmail/Outlook) for sales email tracking",
          "Connect calendar for meeting scheduling"
        ]
      },
      {
        title: "Contact & Deal Management",
        items: [
          "Import deal stages and create associated properties for deals",
          "Define custom properties for contacts and companies",
          "Set up lead scoring based on user behavior and interaction with marketing content"
        ]
      },
      {
        title: "Task & Activity Management",
        items: [
          "Set up task queues for follow-ups and reminders",
          "Create activity tracking (calls, meetings, emails) and link them to appropriate deals",
          "Configure notification settings for key sales actions"
        ]
      },
      {
        title: "Sales Automation",
        items: [
          "Set up sequences for email outreach and follow-ups",
          "Automate meeting scheduling with the calendar tool",
          "Create automation workflows for lead qualification or deal progression"
        ]
      },
      {
        title: "Reporting & Analytics",
        items: [
          "Set up sales dashboards (deal pipeline, closed-won opportunities, revenue forecasting)",
          "Configure reports for sales activities (calls made, meetings booked, etc.)",
          "Track individual rep performance with KPIs"
        ]
      },
      {
        title: "Integrations",
        items: [
          "Integrate with third-party apps like CRMs, email tools, and calendars",
          "Set up phone integration for calling via HubSpot",
          "Sync with other sales tools like LinkedIn Sales Navigator or Zoom"
        ]
      }
    ]
  },
  service: {
    title: "Service Hub Onboarding",
    description: "Ticketing, Knowledge Base & Help Desk",
    sections: [
      {
        title: "Account Setup",
        items: [
          "Set up Service Hub and configure team access",
          "Configure global settings (timezone, branding, etc.)",
          "Set up ticket pipelines based on support process or ticket types"
        ]
      },
      {
        title: "Ticket Management",
        items: [
          "Define ticket properties and custom fields for categorizing issues",
          "Create ticket pipelines (New, In Progress, Resolved)",
          "Set up SLA tracking and notifications",
          "Automate ticket routing and assignment based on ticket criteria"
        ]
      },
      {
        title: "Knowledge Base Setup",
        items: [
          "Create and organize knowledge base articles by categories",
          "Set up search functionality and filtering options for users",
          "Configure permissions for internal vs. public access to knowledge base articles"
        ]
      },
      {
        title: "Customer Feedback & Surveys",
        items: [
          "Set up customer satisfaction surveys (CSAT) or NPS surveys",
          "Automate post-ticket surveys or feedback requests",
          "Create reporting dashboards for survey results"
        ]
      },
      {
        title: "Live Chat & Conversational Bots",
        items: [
          "Set up live chat on the website and configure chatbots for initial support",
          "Define chatbot workflows (qualifying leads, answering FAQs)",
          "Integrate with the Help Desk to convert chat conversations into tickets"
        ]
      },
      {
        title: "Reporting & Analytics",
        items: [
          "Configure dashboards for ticket volume, response times, and customer satisfaction",
          "Set up custom reports for support team performance",
          "Track customer feedback metrics, such as CSAT and NPS scores"
        ]
      }
    ]
  },
  cms: {
    title: "CMS Hub Onboarding",
    description: "Website & Landing Pages",
    sections: [
      {
        title: "Account Setup",
        items: [
          "Set up HubSpot CMS and connect it to your domain",
          "Configure global settings (branding, site-wide settings, etc.)",
          "Set up SSL certificates for security"
        ]
      },
      {
        title: "Website Setup & Structure",
        items: [
          "Define website structure (navigation, pages, categories)",
          "Set up and configure page templates (homepage, landing pages)",
          "Create and configure custom modules for reusable content blocks"
        ]
      },
      {
        title: "Content Creation & Management",
        items: [
          "Set up blog functionality and templates (blog homepage, post layout)",
          "Organize and set up categories and tags for blog content",
          "Configure content publishing workflows (approval stages for posts)"
        ]
      },
      {
        title: "SEO Setup",
        items: [
          "Set up SEO tools and keyword tracking",
          "Configure meta descriptions, title tags, and URL slugs for key pages",
          "Set up on-page SEO features (H1/H2 tags, internal linking, etc.)"
        ]
      },
      {
        title: "Lead Capture & Forms",
        items: [
          "Create and embed forms for lead capture on relevant pages",
          "Set up call-to-action buttons (CTAs) for lead conversion",
          "Create thank-you pages after form submissions"
        ]
      },
      {
        title: "Personalization & Smart Content",
        items: [
          "Configure personalization tokens for dynamic content",
          "Set up smart content based on user behavior, location, or lifecycle stage"
        ]
      },
      {
        title: "Analytics & Performance Tracking",
        items: [
          "Set up Google Analytics tracking or integrate with HubSpot's native reporting tools",
          "Configure dashboards to track website performance",
          "Set up goals and conversion tracking for key pages and actions"
        ]
      }
    ]
  }
};

export default function HubOnboardingContent() {
  return (
    <section className="py-16 bg-card/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center space-y-4 mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
            What's Included in Your Onboarding
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Comprehensive setup and configuration for each HubSpot hub, tailored to your business needs
          </p>
        </motion.div>

        <Tabs defaultValue="marketing" className="w-full">
          <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 mb-8" data-testid="tabs-hub-selector">
            <TabsTrigger value="marketing" data-testid="tab-marketing">
              Marketing Hub
            </TabsTrigger>
            <TabsTrigger value="sales" data-testid="tab-sales">
              Sales Hub
            </TabsTrigger>
            <TabsTrigger value="service" data-testid="tab-service">
              Service Hub
            </TabsTrigger>
            <TabsTrigger value="cms" data-testid="tab-cms">
              CMS Hub
            </TabsTrigger>
          </TabsList>

          {Object.entries(hubContent).map(([key, hub]) => (
            <TabsContent key={key} value={key} className="mt-0">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="border-2">
                  <CardHeader className="border-b bg-card/50">
                    <CardTitle className="text-2xl">{hub.title}</CardTitle>
                    <p className="text-sm text-muted-foreground">{hub.description}</p>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      {hub.sections.map((section, idx) => (
                        <motion.div
                          key={section.title}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.3, delay: idx * 0.05 }}
                          className="space-y-3"
                        >
                          <h4 className="font-semibold text-lg text-foreground flex items-center gap-2">
                            <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                            {section.title}
                          </h4>
                          <ul className="space-y-2">
                            {section.items.map((item, itemIdx) => (
                              <li
                                key={itemIdx}
                                className="flex items-start gap-2 text-sm text-muted-foreground"
                              >
                                <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  );
}
