import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Rocket, Code, Zap, Settings, TrendingUp, TrendingDown, Timer } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

const services = [
  {
    icon: Rocket,
    title: "HubSpot Onboarding/Migration",
    description: "Seamless implementation and migration to HubSpot with expert guidance from setup to full adoption.",
    features: ["Custom Portal Setup", "Data Migration", "Workflow Automation", "Team Training"],
    kpis: [
      { label: "CRM Adoption Rate", type: "increase" },
      { label: "Data Accuracy %", type: "increase" },
      { label: "Time to Go-Live", type: "quick" },
    ],
    link: "/services/hubspot-onboarding",
  },
  {
    icon: Code,
    title: "HubSpot CMS Design and Development",
    description: "Custom website design and development on HubSpot CMS for a powerful, conversion-focused web presence.",
    features: ["Custom Templates", "Responsive Design", "HubDB Integration", "Theme Development"],
    kpis: [
      { label: "Website Conversion Rate", type: "increase" },
      { label: "Landing Page ROI", type: "increase" },
      { label: "Bounce Rate", type: "decrease" },
    ],
    link: "/services/cms-development",
  },
  {
    icon: Zap,
    title: "HubSpot Optimization",
    description: "Maximize your HubSpot ROI with strategic optimization of your existing portal and processes.",
    features: ["Performance Audits", "Process Optimization", "Advanced Automation", "Integration Enhancement"],
    kpis: [
      { label: "Workflow Efficiency", type: "increase" },
      { label: "System Trust", type: "increase" },
      { label: "Sales Cycle Length", type: "decrease" },
    ],
    link: "/services/optimization",
  },
  {
    icon: Settings,
    title: "HubSpot Admin",
    description: "Ongoing administrative support to keep your HubSpot portal running smoothly and efficiently.",
    features: ["Portal Management", "User Administration", "Maintenance & Updates", "Technical Support"],
    kpis: [
      { label: "Automation Error Rate", type: "decrease" },
      { label: "Dashboard Usage Rate", type: "increase" },
      { label: "User Satisfaction", type: "increase" },
    ],
    link: "/services/admin",
  },
];

export default function Services() {
  return (
    <section id="services" className="py-20 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-muted/20 to-background"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center space-y-4 mb-20">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Our Services</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Comprehensive HubSpot solutions designed to accelerate your growth and streamline operations
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {services.map((service, index) => (
            <motion.div 
              key={service.title} 
              className="group relative"
              data-testid={`card-${service.title.toLowerCase().replace(/\s+/g, '-')}`}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="absolute -inset-0.5 bg-gradient-to-r from-primary/20 to-primary/5 rounded-lg opacity-0 group-hover:opacity-100 transition duration-300 blur"></div>
              
              <Card className="relative h-full border-2 hover-elevate transition-all duration-300">
                <CardHeader className="space-y-6 pb-8">
                  <div className="flex items-start justify-between gap-4">
                    <div className="w-14 h-14 bg-gradient-to-br from-primary/20 to-primary/5 rounded-lg flex items-center justify-center flex-shrink-0">
                      <service.icon className="h-7 w-7 text-primary" />
                    </div>
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-primary">{index + 1}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <CardTitle className="text-2xl font-bold">{service.title}</CardTitle>
                    <CardDescription className="text-base leading-relaxed">
                      {service.description}
                    </CardDescription>
                  </div>
                </CardHeader>
                
                <CardContent className="pt-0 space-y-6">
                  <div className="flex gap-6">
                    <div className="flex-1 space-y-3">
                      {service.features.map((feature) => (
                        <div key={feature} className="flex items-start gap-3">
                          <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                          <p className="text-sm text-muted-foreground">{feature}</p>
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex items-center justify-center">
                      <div className="flex flex-col gap-3">
                        {service.kpis.map((kpi) => {
                          const KpiIcon = kpi.type === "increase" ? TrendingUp : kpi.type === "decrease" ? TrendingDown : Timer;
                          return (
                            <div key={kpi.label} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary/5 border border-primary/20">
                              <KpiIcon className="h-4 w-4 text-primary flex-shrink-0" />
                              <p className="text-xs font-semibold text-primary whitespace-nowrap">{kpi.label}</p>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-2">
                    {service.link ? (
                      <Button 
                        variant="outline" 
                        className="w-full border-primary/20 hover:bg-primary/5"
                        data-testid={`button-learn-more-${service.title.toLowerCase().replace(/\s+/g, '-')}`}
                        asChild
                      >
                        <Link href={service.link}>Learn More</Link>
                      </Button>
                    ) : (
                      <Button 
                        variant="outline" 
                        className="w-full border-primary/20 hover:bg-primary/5"
                        data-testid={`button-book-call-${service.title.toLowerCase().replace(/\s+/g, '-')}`}
                        asChild
                      >
                        <a href={`/book-call?utm_source=homepage&utm_medium=services&utm_campaign=${service.title.toLowerCase().replace(/\s+/g, '_')}`}>Book a Call</a>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
