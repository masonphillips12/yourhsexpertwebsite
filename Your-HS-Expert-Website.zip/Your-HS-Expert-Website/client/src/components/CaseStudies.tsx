import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

const caseStudies = [
  {
    company: "The Franchise Navigator",
    industry: "Franchising",
    challenge: "Migrating from another CRM to HubSpot",
    results: [
      { metric: "70%", label: "Decreased Manual Sales Process" },
      { metric: "40%", label: "Time Saved" },
      { metric: "85%", label: "Platform Adoption" },
    ],
    testimonial: "Transitioning from a standard CRM to HubSpot was a complex process, but Mason Phillips made it seamless. He successfully migrated our data, optimized workflows, and tailored the system to our business needs. His expertise and attention to detail greatly improved our CRM's efficiency. I highly recommend Mason.",
    author: "Chris Whipple, Owner of TheFranchiseNavigator.com",
  },
  {
    company: "Elevate Medical Solutions",
    industry: "Healthcare",
    challenge: "HubSpot Optimization",
    results: [
      { metric: "95%", label: "Increased Data Hygiene" },
      { metric: "60%", label: "Increased HubSpot Usage" },
      { metric: "80%", label: "Eliminated Manual Tasks" },
    ],
    testimonial: "Mason is an exceptional HubSpot expert! His deep knowledge and expertise shine through in every interaction, and he's incredibly responsive to our needs. Mason consistently delivers solutions that drive results. Highly recommend him!",
    author: "Katie Kovar, Marketing Director at Elevate Medical Solutions",
  },
  {
    company: "Tosi",
    industry: "Industrial Technology",
    challenge: "CMS Rebrand",
    results: [
      { metric: "145%", label: "Increased Conversion Rate" },
      { metric: "35%", label: "Decreased Bounce Rate" },
      { metric: "3x", label: "Landing Page ROI" },
    ],
    testimonial: "Great collaboration with Mason Phillips on leading the website redesign for Tosi in HubSpot. Happy client and great site! Couldn't ask for more.",
    author: "Nishat Jones, Founder, Chief Growth & Marketing Officer",
  },
];

export default function CaseStudies() {
  return (
    <section id="case-studies" className="py-20 md:py-32 bg-card/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Client Success Stories</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Real results from businesses that trusted us with their HubSpot transformation
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {caseStudies.map((study, i) => (
            <motion.div
              key={study.company}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: i * 0.15 }}
            >
              <Card className="flex flex-col hover-elevate transition-all h-full" data-testid={`card-case-study-${study.company.toLowerCase().replace(/\s+/g, '-')}`}>
                <CardHeader className="space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <CardTitle className="text-xl mb-2">{study.company}</CardTitle>
                      <Badge variant="secondary" className="text-xs">
                        {study.industry}
                      </Badge>
                    </div>
                    <TrendingUp className="h-5 w-5 text-primary flex-shrink-0" />
                  </div>
                  <p className="text-sm text-muted-foreground">{study.challenge}</p>
                </CardHeader>

                <CardContent className="flex-1 space-y-6">
                  <div className="grid grid-cols-3 gap-4">
                    {study.results.map((result) => (
                      <div key={result.label} className="text-center">
                        <div className="text-2xl font-bold text-primary">{result.metric}</div>
                        <div className="text-xs text-muted-foreground mt-1">{result.label}</div>
                      </div>
                    ))}
                  </div>

                  <div className="pt-6 border-t space-y-3">
                    <p className="text-sm italic">"{study.testimonial}"</p>
                    <p className="text-xs text-muted-foreground">— {study.author}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
