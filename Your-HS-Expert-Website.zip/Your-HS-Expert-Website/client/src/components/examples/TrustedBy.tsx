import TrustedBy from '../TrustedBy';

export default function TrustedByExample() {
  return <TrustedBy />;
}
