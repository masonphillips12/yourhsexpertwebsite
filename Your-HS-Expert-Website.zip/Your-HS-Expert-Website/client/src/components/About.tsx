import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Award, Users2, Target, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

const certifications = [
  "HubSpot Solutions Partner",
  "Elite Tier Certified",
  "Inbound Marketing Certified",
  "Sales Enablement Certified",
];

const values = [
  {
    icon: Award,
    title: "Expertise You Can Trust",
    description: "Our team holds the highest HubSpot certifications and brings 15+ years of combined experience.",
  },
  {
    icon: Users2,
    title: "Client-First Approach",
    description: "We partner with you to understand your unique challenges and craft tailored solutions.",
  },
  {
    icon: Target,
    title: "Results-Driven",
    description: "Every implementation is focused on delivering measurable ROI and business growth.",
  },
  {
    icon: Sparkles,
    title: "Innovation & Excellence",
    description: "We stay ahead of HubSpot's latest features to give you a competitive advantage.",
  },
];

export default function About() {
  return (
    <section id="about" className="py-20 md:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
                Your Trusted HubSpot Partner
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                We're not just consultants—we're growth partners committed to helping businesses like yours
                maximize their HubSpot investment and achieve transformative results.
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-semibold">Certifications & Credentials</h3>
              <div className="flex flex-wrap gap-3">
                {certifications.map((cert) => (
                  <Badge key={cert} variant="secondary" className="text-sm" data-testid={`badge-cert-${cert.toLowerCase().replace(/\s+/g, '-')}`}>
                    {cert}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="p-6 bg-primary/5 rounded-md border border-primary/10">
              <p className="text-sm text-foreground">
                <span className="font-semibold text-primary">200+ successful projects</span> across
                industries including SaaS, Healthcare, Manufacturing, and Professional Services.
              </p>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            {values.map((value, i) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
              >
                <Card className="hover-elevate transition-all h-full" data-testid={`card-value-${value.title.toLowerCase().replace(/\s+/g, '-')}`}>
                  <CardContent className="p-6 space-y-3">
                    <motion.div 
                      className="w-10 h-10 bg-primary/10 rounded-md flex items-center justify-center"
                      whileHover={{ rotate: 5, scale: 1.1 }}
                      transition={{ duration: 0.2 }}
                    >
                      <value.icon className="h-5 w-5 text-primary" />
                    </motion.div>
                    <h4 className="font-semibold">{value.title}</h4>
                    <p className="text-sm text-muted-foreground">{value.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
