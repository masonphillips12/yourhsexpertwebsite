import { useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Contact() {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://static.hsappstatic.net/MeetingsEmbed/ex/MeetingsEmbedCode.js';
    script.type = 'text/javascript';
    script.async = true;
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return (
    <section id="contact" className="py-20 md:py-32 bg-gradient-to-b from-background to-card/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Book a Call</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Schedule your complimentary consultation to explore how HubSpot can transform your business
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 items-start">
          <motion.div 
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6">
                <div 
                  className="meetings-iframe-container" 
                  data-src="https://meetings.hubspot.com/yourhubspotexpert/intro-call?embed=true"
                  data-testid="hubspot-calendar-embed"
                />
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card className="bg-primary text-primary-foreground border-primary">
              <CardContent className="p-6 space-y-4">
                <h4 className="text-xl font-semibold">What to Expect</h4>
                <p className="text-primary-foreground/90 text-sm">
                  This is a 30-minute call where we'll get a high-level understanding of your needs and pain points to see if we're a good fit.
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
