import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContentSchema, insertCategorySchema, insertTagSchema } from "@shared/schema";
import { z } from "zod";
import { ObjectStorageService, ObjectNotFoundError } from "./objectStorage";
import { setupAuth, isAuthenticated, isAdmin } from "./replitAuth";

function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/--+/g, '-')
    .trim();
}

function calculateReadingTime(content: string): number {
  const wordsPerMinute = 200;
  const wordCount = content.split(/\s+/).length;
  return Math.ceil(wordCount / wordsPerMinute);
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication (Replit Auth)
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Content routes (read operations are public, mutations require admin)
  app.get("/api/content", async (req, res) => {
    try {
      const { type, status, categoryId, tagId } = req.query;
      const content = await storage.getAllContent({
        type: type as string,
        status: status as string,
        categoryId: categoryId as string,
        tagId: tagId as string,
      });
      
      // Fetch categories and tags for each content
      const enrichedContent = await Promise.all(
        content.map(async (c) => ({
          ...c,
          categories: await storage.getContentCategories(c.id),
          tags: await storage.getContentTags(c.id),
        }))
      );
      
      res.json(enrichedContent);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/content/popular/:type", async (req, res) => {
    try {
      const { type } = req.params;
      const limit = parseInt(req.query.limit as string) || 5;
      const content = await storage.getPopularContent(type, limit);
      res.json(content);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/content/search", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q) {
        return res.status(400).json({ message: "Search query required" });
      }
      const results = await storage.searchContent(q as string);
      res.json(results);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/content/slug/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const content = await storage.getContentBySlug(slug);
      
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }

      const categories = await storage.getContentCategories(content.id);
      const tags = await storage.getContentTags(content.id);

      res.json({ ...content, categories, tags });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/content/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const content = await storage.getContent(id);
      
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }

      const categories = await storage.getContentCategories(content.id);
      const tags = await storage.getContentTags(content.id);

      res.json({ ...content, categories, tags });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/content", isAdmin, async (req, res) => {
    try {
      const { categoryIds, tagIds, ...contentData } = req.body;
      
      // Auto-generate slug if not provided
      if (!contentData.slug && contentData.title) {
        contentData.slug = generateSlug(contentData.title);
      }

      // Check for slug conflicts
      if (contentData.slug) {
        const existing = await storage.getContentBySlug(contentData.slug);
        if (existing) {
          // Generate a unique slug by appending a timestamp
          contentData.slug = `${contentData.slug}-${Date.now()}`;
        }
      }

      // Auto-calculate reading time for blogs
      if (contentData.type === 'blog' && contentData.content) {
        contentData.readingTime = calculateReadingTime(contentData.content);
      }

      // Set publishedAt if status is published
      if (contentData.status === 'published' && !contentData.publishedAt) {
        contentData.publishedAt = new Date();
      }

      const validated = insertContentSchema.parse(contentData);
      const content = await storage.createContent(validated, categoryIds, tagIds);
      
      const categories = await storage.getContentCategories(content.id);
      const tags = await storage.getContentTags(content.id);

      res.status(201).json({ ...content, categories, tags });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      if (error.code === '23505') { // PostgreSQL unique constraint error
        return res.status(409).json({ message: "Slug already exists" });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/content/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { categoryIds, tagIds, ...updateData } = req.body;

      // Get existing content to determine type
      const existing = await storage.getContent(id);
      if (!existing) {
        return res.status(404).json({ message: "Content not found" });
      }

      // Update slug if title changed
      if (updateData.title && !updateData.slug) {
        updateData.slug = generateSlug(updateData.title);
      }

      // Check for slug conflicts
      if (updateData.slug && updateData.slug !== existing.slug) {
        const conflict = await storage.getContentBySlug(updateData.slug);
        if (conflict && conflict.id !== id) {
          return res.status(409).json({ message: "Slug already exists" });
        }
      }

      // Update reading time for blogs (use existing type if not provided)
      const contentType = updateData.type || existing.type;
      if (contentType === 'blog' && updateData.content) {
        updateData.readingTime = calculateReadingTime(updateData.content);
      }

      // Set publishedAt when publishing
      if (updateData.status === 'published' && !existing.publishedAt && !updateData.publishedAt) {
        updateData.publishedAt = new Date();
      }

      // Validate update data with partial schema
      const partialSchema = insertContentSchema.partial();
      const validated = partialSchema.parse(updateData);

      const content = await storage.updateContent(id, validated, categoryIds, tagIds);
      
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }

      const categories = await storage.getContentCategories(content.id);
      const tags = await storage.getContentTags(content.id);

      res.json({ ...content, categories, tags });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      if (error.code === '23505') { // PostgreSQL unique constraint error
        return res.status(409).json({ message: "Slug already exists" });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/content/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteContent(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Content not found" });
      }

      res.json({ message: "Content deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/content/:id/view", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.incrementViews(id);
      res.json({ message: "View counted" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Category routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/categories/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const category = await storage.getCategory(id);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }

      res.json(category);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/categories", isAdmin, async (req, res) => {
    try {
      if (!req.body.slug && req.body.name) {
        req.body.slug = generateSlug(req.body.name);
      }
      
      const validated = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(validated);
      res.status(201).json(category);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/categories/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      
      if (req.body.name && !req.body.slug) {
        req.body.slug = generateSlug(req.body.name);
      }

      const category = await storage.updateCategory(id, req.body);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }

      res.json(category);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/categories/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteCategory(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Category not found" });
      }

      res.json({ message: "Category deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Tag routes
  app.get("/api/tags", async (req, res) => {
    try {
      const tags = await storage.getAllTags();
      res.json(tags);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tags/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const tag = await storage.getTag(id);
      
      if (!tag) {
        return res.status(404).json({ message: "Tag not found" });
      }

      res.json(tag);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tags", isAdmin, async (req, res) => {
    try {
      if (!req.body.slug && req.body.name) {
        req.body.slug = generateSlug(req.body.name);
      }
      
      const validated = insertTagSchema.parse(req.body);
      const tag = await storage.createTag(validated);
      res.status(201).json(tag);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/tags/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      
      if (req.body.name && !req.body.slug) {
        req.body.slug = generateSlug(req.body.name);
      }

      const tag = await storage.updateTag(id, req.body);
      
      if (!tag) {
        return res.status(404).json({ message: "Tag not found" });
      }

      res.json(tag);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/tags/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteTag(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Tag not found" });
      }

      res.json({ message: "Tag deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Object storage routes for public file serving
  app.get("/public-objects/:filePath(*)", async (req, res) => {
    const filePath = req.params.filePath;
    try {
      const objectStorageService = new ObjectStorageService();
      const file = await objectStorageService.searchPublicObject(filePath);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      objectStorageService.downloadObject(file, res);
    } catch (error: any) {
      console.error("Error searching for public object:", error);
      if (error.message?.includes("PUBLIC_OBJECT_SEARCH_PATHS not set")) {
        return res.status(503).json({ 
          error: "Object storage not configured. Please set up object storage environment variables." 
        });
      }
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  // Object storage routes for CMS image uploads
  app.get("/objects/:objectPath(*)", async (req, res) => {
    try {
      const objectStorageService = new ObjectStorageService();
      const objectFile = await objectStorageService.getObjectEntityFile(
        req.path,
      );
      objectStorageService.downloadObject(objectFile, res);
    } catch (error: any) {
      console.error("Error checking object access:", error);
      if (error instanceof ObjectNotFoundError) {
        return res.sendStatus(404);
      }
      if (error.message?.includes("PRIVATE_OBJECT_DIR not set")) {
        return res.status(503).json({ 
          error: "Object storage not configured. Please set up object storage environment variables." 
        });
      }
      return res.sendStatus(500);
    }
  });

  app.post("/api/objects/upload", isAdmin, async (req, res) => {
    try {
      const objectStorageService = new ObjectStorageService();
      const uploadURL = await objectStorageService.getObjectEntityUploadURL();
      res.json({ uploadURL });
    } catch (error: any) {
      console.error("Error getting upload URL:", error);
      if (error.message?.includes("PRIVATE_OBJECT_DIR not set") || 
          error.message?.includes("Object storage not configured")) {
        return res.status(503).json({ 
          error: "Object storage not configured. Please set up object storage in the Object Storage tool pane." 
        });
      }
      return res.status(500).json({ error: "Failed to generate upload URL" });
    }
  });

  app.put("/api/content-images", isAdmin, async (req, res) => {
    if (!req.body.imageURL) {
      return res.status(400).json({ error: "imageURL is required" });
    }

    try {
      const objectStorageService = new ObjectStorageService();
      const objectPath = objectStorageService.normalizeObjectEntityPath(
        req.body.imageURL,
      );

      res.status(200).json({
        objectPath: objectPath,
      });
    } catch (error: any) {
      console.error("Error setting content image:", error);
      if (error.message?.includes("PRIVATE_OBJECT_DIR not set")) {
        return res.status(503).json({ 
          error: "Object storage not configured" 
        });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
