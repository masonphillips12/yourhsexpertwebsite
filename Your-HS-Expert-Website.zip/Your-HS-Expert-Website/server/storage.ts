import { 
  type User, 
  type UpsertUser,
  type Content,
  type InsertContent,
  type Category,
  type InsertCategory,
  type Tag,
  type InsertTag
} from "@shared/schema";

export interface IStorage {
  // User methods (Replit Auth integration)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Content methods
  getContent(id: string): Promise<Content | undefined>;
  getContentBySlug(slug: string): Promise<Content | undefined>;
  getAllContent(filters?: { type?: string; status?: string; categoryId?: string; tagId?: string }): Promise<Content[]>;
  getPopularContent(type: string, limit: number): Promise<Content[]>;
  createContent(content: InsertContent, categoryIds?: string[], tagIds?: string[]): Promise<Content>;
  updateContent(id: string, content: Partial<InsertContent>, categoryIds?: string[], tagIds?: string[]): Promise<Content | undefined>;
  deleteContent(id: string): Promise<boolean>;
  incrementViews(id: string): Promise<void>;
  searchContent(query: string): Promise<Content[]>;
  
  // Category methods
  getCategory(id: string): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  getAllCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: string, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: string): Promise<boolean>;
  
  // Tag methods
  getTag(id: string): Promise<Tag | undefined>;
  getTagBySlug(slug: string): Promise<Tag | undefined>;
  getAllTags(): Promise<Tag[]>;
  createTag(tag: InsertTag): Promise<Tag>;
  updateTag(id: string, tag: Partial<InsertTag>): Promise<Tag | undefined>;
  deleteTag(id: string): Promise<boolean>;
  
  // Helper methods for content relationships
  getContentCategories(contentId: string): Promise<Category[]>;
  getContentTags(contentId: string): Promise<Tag[]>;
}

import { db } from "./db";
import { 
  users, 
  content, 
  categories, 
  tags,
  contentCategories,
  contentTags 
} from "@shared/schema";
import { eq, and, or, desc, ilike, sql } from "drizzle-orm";

export class DatabaseStorage implements IStorage {
  // User methods (Replit Auth integration)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Content methods
  async getContent(id: string): Promise<Content | undefined> {
    const [result] = await db.select().from(content).where(eq(content.id, id));
    return result || undefined;
  }

  async getContentBySlug(slug: string): Promise<Content | undefined> {
    const [result] = await db.select().from(content).where(eq(content.slug, slug));
    return result || undefined;
  }

  async getAllContent(filters?: { type?: string; status?: string; categoryId?: string; tagId?: string }): Promise<Content[]> {
    let query = db.select().from(content);
    const conditions = [];

    if (filters?.type) {
      conditions.push(eq(content.type, filters.type));
    }
    if (filters?.status) {
      conditions.push(eq(content.status, filters.status));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }

    let results = await query.orderBy(desc(content.createdAt));

    // Filter by category or tag if specified
    if (filters?.categoryId) {
      const contentIds = (await db
        .select({ contentId: contentCategories.contentId })
        .from(contentCategories)
        .where(eq(contentCategories.categoryId, filters.categoryId))
      ).map(r => r.contentId);
      results = results.filter(c => contentIds.includes(c.id));
    }

    if (filters?.tagId) {
      const contentIds = (await db
        .select({ contentId: contentTags.contentId })
        .from(contentTags)
        .where(eq(contentTags.tagId, filters.tagId))
      ).map(r => r.contentId);
      results = results.filter(c => contentIds.includes(c.id));
    }

    return results;
  }

  async getPopularContent(type: string, limit: number): Promise<Content[]> {
    return await db
      .select()
      .from(content)
      .where(and(eq(content.type, type), eq(content.status, 'published')))
      .orderBy(desc(content.views))
      .limit(limit);
  }

  async createContent(insertContent: InsertContent, categoryIds?: string[], tagIds?: string[]): Promise<Content> {
    const [newContent] = await db.insert(content).values(insertContent).returning();
    
    // Add category relationships
    if (categoryIds && categoryIds.length > 0) {
      await db.insert(contentCategories).values(
        categoryIds.map(categoryId => ({ contentId: newContent.id, categoryId }))
      );
    }

    // Add tag relationships
    if (tagIds && tagIds.length > 0) {
      await db.insert(contentTags).values(
        tagIds.map(tagId => ({ contentId: newContent.id, tagId }))
      );
    }

    return newContent;
  }

  async updateContent(id: string, updateData: Partial<InsertContent>, categoryIds?: string[], tagIds?: string[]): Promise<Content | undefined> {
    const [updated] = await db
      .update(content)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(content.id, id))
      .returning();

    if (!updated) return undefined;

    // Update category relationships
    if (categoryIds !== undefined) {
      await db.delete(contentCategories).where(eq(contentCategories.contentId, id));
      if (categoryIds.length > 0) {
        await db.insert(contentCategories).values(
          categoryIds.map(categoryId => ({ contentId: id, categoryId }))
        );
      }
    }

    // Update tag relationships
    if (tagIds !== undefined) {
      await db.delete(contentTags).where(eq(contentTags.contentId, id));
      if (tagIds.length > 0) {
        await db.insert(contentTags).values(
          tagIds.map(tagId => ({ contentId: id, tagId }))
        );
      }
    }

    return updated;
  }

  async deleteContent(id: string): Promise<boolean> {
    const result = await db.delete(content).where(eq(content.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async incrementViews(id: string): Promise<void> {
    await db
      .update(content)
      .set({ views: sql`${content.views} + 1` })
      .where(eq(content.id, id));
  }

  async searchContent(query: string): Promise<Content[]> {
    const searchPattern = `%${query}%`;
    return await db
      .select()
      .from(content)
      .where(
        and(
          eq(content.status, 'published'),
          or(
            ilike(content.title, searchPattern),
            ilike(content.excerpt, searchPattern),
            ilike(content.content, searchPattern)
          )
        )
      )
      .orderBy(desc(content.createdAt));
  }

  // Category methods
  async getCategory(id: string): Promise<Category | undefined> {
    const [result] = await db.select().from(categories).where(eq(categories.id, id));
    return result || undefined;
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const [result] = await db.select().from(categories).where(eq(categories.slug, slug));
    return result || undefined;
  }

  async getAllCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(categories.name);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const [category] = await db.insert(categories).values(insertCategory).returning();
    return category;
  }

  async updateCategory(id: string, updateData: Partial<InsertCategory>): Promise<Category | undefined> {
    const [updated] = await db
      .update(categories)
      .set(updateData)
      .where(eq(categories.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteCategory(id: string): Promise<boolean> {
    const result = await db.delete(categories).where(eq(categories.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Tag methods
  async getTag(id: string): Promise<Tag | undefined> {
    const [result] = await db.select().from(tags).where(eq(tags.id, id));
    return result || undefined;
  }

  async getTagBySlug(slug: string): Promise<Tag | undefined> {
    const [result] = await db.select().from(tags).where(eq(tags.slug, slug));
    return result || undefined;
  }

  async getAllTags(): Promise<Tag[]> {
    return await db.select().from(tags).orderBy(tags.name);
  }

  async createTag(insertTag: InsertTag): Promise<Tag> {
    const [tag] = await db.insert(tags).values(insertTag).returning();
    return tag;
  }

  async updateTag(id: string, updateData: Partial<InsertTag>): Promise<Tag | undefined> {
    const [updated] = await db
      .update(tags)
      .set(updateData)
      .where(eq(tags.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteTag(id: string): Promise<boolean> {
    const result = await db.delete(tags).where(eq(tags.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Helper methods for content relationships
  async getContentCategories(contentId: string): Promise<Category[]> {
    const results = await db
      .select({ category: categories })
      .from(contentCategories)
      .innerJoin(categories, eq(contentCategories.categoryId, categories.id))
      .where(eq(contentCategories.contentId, contentId));
    return results.map(r => r.category);
  }

  async getContentTags(contentId: string): Promise<Tag[]> {
    const results = await db
      .select({ tag: tags })
      .from(contentTags)
      .innerJoin(tags, eq(contentTags.tagId, tags.id))
      .where(eq(contentTags.contentId, contentId));
    return results.map(r => r.tag);
  }
}

export const storage = new DatabaseStorage();
