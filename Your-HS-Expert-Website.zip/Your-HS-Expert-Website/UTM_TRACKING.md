# UTM Tracking System

## Overview
Comprehensive UTM parameter tracking across the entire website to measure which pages, sections, and CTAs drive "Book a Call" conversions. This enables data-driven optimization of your marketing funnel and content strategy.

## UTM Parameters Structure

### Homepage

#### Hero Section
**Main CTA Button**:
- **utm_source**: `homepage`
- **utm_medium**: `hero`
- **utm_campaign**: `main_cta`

**Example URL**:
```
https://yourhsexpert.com/book-call?utm_source=homepage&utm_medium=hero&utm_campaign=main_cta
```

#### Services Section
**Service-specific CTA Buttons** (for services without detail pages):
- **utm_source**: `homepage`
- **utm_medium**: `services`
- **utm_campaign**: `{service_name}` (e.g., "platform_customization")

**Example URL**:
```
https://yourhsexpert.com/book-call?utm_source=homepage&utm_medium=services&utm_campaign=platform_customization
```

### Navigation Header

#### Desktop Header
- **utm_source**: `navigation`
- **utm_medium**: `header`
- **utm_campaign**: `global_cta`

#### Mobile Header
- **utm_source**: `navigation`
- **utm_medium**: `header_mobile`
- **utm_campaign**: `global_cta`

**Example URL**:
```
https://yourhsexpert.com/book-call?utm_source=navigation&utm_medium=header&utm_campaign=global_cta
```

### Interactive Tools

#### HubSpot Calculator
**Post-unlock CTA**:
- **utm_source**: `calculator`
- **utm_medium**: `tool`
- **utm_campaign**: `price_estimate`

**Example URL**:
```
https://yourhsexpert.com/book-call?utm_source=calculator&utm_medium=tool&utm_campaign=price_estimate
```

### Service Detail Pages

#### HubSpot Onboarding Page
**Hero CTA**:
- **utm_source**: `service_page`
- **utm_medium**: `hero`
- **utm_campaign**: `hubspot_onboarding`

**Bottom CTA**:
- **utm_source**: `service_page`
- **utm_medium**: `bottom_cta`
- **utm_campaign**: `hubspot_onboarding`

#### Optimization Page
**Hero CTA**:
- **utm_source**: `service_page`
- **utm_medium**: `hero`
- **utm_campaign**: `optimization`

#### CMS Development Page
**Hero CTA**:
- **utm_source**: `service_page`
- **utm_medium**: `hero`
- **utm_campaign**: `cms_development`

#### Admin Page
**Hero CTA**:
- **utm_source**: `service_page`
- **utm_medium**: `hero`
- **utm_campaign**: `admin_support`

**Example URL**:
```
https://yourhsexpert.com/book-call?utm_source=service_page&utm_medium=hero&utm_campaign=hubspot_onboarding
```

### Content Marketing

#### Blog Posts
**Sidebar CTA** (Individual blog post pages):
- **utm_source**: `blog`
- **utm_medium**: `content`
- **utm_campaign**: `{blog-slug}` (e.g., "5-hubspot-automation-tips")
- **utm_content**: `sidebar_cta`

**Empty State CTA** (Blog listing page when no posts):
- **utm_source**: `blog`
- **utm_medium**: `content`
- **utm_campaign**: `blog_index`
- **utm_content**: `empty_state_cta`

**Example URL**:
```
https://yourhsexpert.com/book-call?utm_source=blog&utm_medium=content&utm_campaign=5-hubspot-automation-tips&utm_content=sidebar_cta
```

#### Case Studies
**Sidebar CTA** (Individual case study pages):
- **utm_source**: `case_studies`
- **utm_medium**: `content`
- **utm_campaign**: `{case-study-slug}` (e.g., "tosi-lead-quality-improvement")
- **utm_content**: `sidebar_cta`

**Example URL**:
```
https://yourhsexpert.com/book-call?utm_source=case_studies&utm_medium=content&utm_campaign=tosi-lead-quality-improvement&utm_content=sidebar_cta
```

## UTM Parameter Definitions

### utm_source
Identifies where the traffic is coming from:
- `homepage` - Main landing page
- `navigation` - Global navigation header
- `calculator` - Interactive pricing calculator
- `service_page` - Individual service detail pages
- `blog` - Blog content
- `case_studies` - Case study content

### utm_medium
Describes the marketing medium:
- `hero` - Hero section CTA
- `services` - Services section
- `header` / `header_mobile` - Navigation header
- `tool` - Interactive tool (calculator)
- `bottom_cta` - Bottom page CTA
- `content` - Content marketing (blog/case studies)

### utm_campaign
Specific campaign identifier:
- `main_cta` - Primary homepage CTA
- `global_cta` - Global navigation CTA
- `price_estimate` - Calculator-driven leads
- `hubspot_onboarding` - Onboarding service
- `optimization` - Optimization service
- `cms_development` - CMS development service
- `admin_support` - Admin support service
- `{blog-slug}` - Individual blog post
- `{case-study-slug}` - Individual case study

### utm_content (optional)
Differentiates similar content/links:
- `sidebar_cta` - Sidebar call-to-action
- `empty_state_cta` - Empty state CTA

## Tracking in Analytics

### Google Analytics 4
These UTM parameters will automatically appear in GA4 under:
- **Acquisition** > **Traffic acquisition** > View by Source/Medium
- **Engagement** > **Conversions** > Campaign performance
- **Reports** > **Engagement** > **Events** > Filter by parameters

**Key Reports to Create**:
1. **CTA Performance**: Compare conversion rates by utm_medium (hero, header, services, etc.)
2. **Page Performance**: Analyze which utm_source drives highest quality leads
3. **Content ROI**: Track blog/case study conversions by campaign slug
4. **Calculator Impact**: Measure price_estimate campaign effectiveness

### HubSpot
If your HubSpot calendar or forms capture UTM parameters:
- Original Source: First utm_source value
- Original Source Drill-Down 1: First utm_medium value
- Original Source Drill-Down 2: First utm_campaign value

**Create Custom Reports**:
1. Deals by Original Source (homepage, blog, calculator, etc.)
2. Lead Quality Score by UTM Campaign
3. Service Interest by Landing Page Campaign

## Benefits

### Conversion Optimization
1. **CTA Testing**: Identify which button placements convert best
2. **Page Performance**: See which service pages drive most bookings
3. **Journey Mapping**: Understand visitor paths to conversion
4. **Calculator ROI**: Measure impact of interactive pricing tool

### Content Strategy
1. **Content ROI**: Measure which blog posts and case studies generate qualified leads
2. **Topic Validation**: Identify subjects that resonate with target audience
3. **Attribution**: Track complete customer journey from content to conversion
4. **Performance Patterns**: Replicate success from high-converting content

### Business Intelligence
1. **Channel Effectiveness**: Compare navigation vs hero vs calculator conversions
2. **Resource Allocation**: Invest in highest-performing CTAs and pages
3. **User Behavior**: Understand which touchpoints matter most
4. **Marketing Mix**: Optimize balance between content, tools, and direct CTAs

## Best Practices

### Regular Analysis
- Review UTM data weekly to identify trends
- Create GA4 custom reports for quick insights
- Share top performers with marketing team
- Use data to inform website optimization

### A/B Testing Opportunities
- Test different hero CTA copy with utm_content variants
- Compare sidebar vs inline CTAs in blog posts
- Experiment with calculator placement and messaging
- Try different service page CTA positions

### Campaign Hygiene
- Keep slug-based campaigns consistent
- Never change published content slugs (breaks tracking)
- Use descriptive, lowercase campaigns with underscores
- Document any custom UTM parameter additions

### Conversion Tracking Setup
1. Ensure HubSpot calendar booking captures UTM parameters
2. Set up GA4 conversion events for /book-call page
3. Create attribution reports in HubSpot
4. Build dashboards for real-time performance monitoring

## Analytics Dashboard Recommendations

### Key Metrics to Track
1. **Conversion Rate by Source** (homepage, navigation, calculator, etc.)
2. **CTA Performance** (hero, header, services, bottom_cta)
3. **Service Interest** (which campaigns drive most bookings)
4. **Content Attribution** (blog/case study conversion rates)
5. **Calculator Effectiveness** (price_estimate campaign performance)
6. **Mobile vs Desktop** (header vs header_mobile)

### Suggested GA4 Explorations
- **Funnel Analysis**: Homepage view → CTA click → Booking confirmation
- **Segment Overlap**: Users who view calculator vs immediate hero CTA clicks
- **Path Analysis**: Navigation patterns before booking conversion
- **Cohort Analysis**: Return visitors vs first-time converters by source

## Future Enhancements

Potential additions to consider:
- UTM tracking on social share buttons
- Newsletter UTM parameters for email campaigns  
- A/B testing different CTA copy with utm_content variants
- Exit intent popup with specific tracking
- Footer CTA buttons with dedicated parameters
- Testimonial section CTAs
