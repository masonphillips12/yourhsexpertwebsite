import React, { useState, useMemo } from 'react';
import { Calculator, AlertCircle, DollarSign, Calendar, Lock, X } from 'lucide-react';

const HubSpotCalculator = () => {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ firstName: '', lastName: '', email: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [hubs, setHubs] = useState({
    salesHub: { enabled: false, tier: 'professional', name: 'Sales Hub', pricing: { professional: 3000, enterprise: 3500 } },
    marketingHub: { enabled: false, tier: 'professional', name: 'Marketing Hub', pricing: { professional: 3000, enterprise: 7000 } },
    serviceHub: { enabled: false, tier: 'professional', name: 'Service Hub', pricing: { professional: 3000, enterprise: 3500 } },
    cmsHub: { enabled: false, tier: 'professional', name: 'CMS Hub', pricing: { professional: 800, enterprise: 2000 } }
  });

  const [riskFactors, setRiskFactors] = useState({
    dataVolume: { value: 1, name: 'Data Volume', description: 'Contacts', scale: [
      { value: 1, label: 'Under 10k', multiplier: 1.0 },
      { value: 2, label: '10k-50k', multiplier: 1.07 },
      { value: 3, label: '50k-250k', multiplier: 1.175 },
      { value: 4, label: '250k-1M', multiplier: 1.28 },
      { value: 5, label: 'Over 1M', multiplier: 1.42 }
    ]},
    teamSize: { value: 3, name: 'Team Size', description: 'Users', scale: [
      { value: 1, label: '1-5', multiplier: 1.0 },
      { value: 2, label: '6-15', multiplier: 1.07 },
      { value: 3, label: '16-30', multiplier: 1.14 },
      { value: 4, label: '31-50', multiplier: 1.21 },
      { value: 5, label: '50+', multiplier: 1.28 }
    ]},
    customization: { value: 3, name: 'Customization', description: 'Workflows', scale: [
      { value: 1, label: 'Minimal', multiplier: 1.0 },
      { value: 2, label: 'Light', multiplier: 1.07 },
      { value: 3, label: 'Moderate', multiplier: 1.175 },
      { value: 4, label: 'Heavy', multiplier: 1.28 },
      { value: 5, label: 'Extensive', multiplier: 1.42 }
    ]},
    integrations: { value: 2, name: 'Integrations', description: 'Systems', scale: [
      { value: 1, label: 'None', multiplier: 1.0 },
      { value: 2, label: '1-2', multiplier: 1.105 },
      { value: 3, label: '3-5', multiplier: 1.21 },
      { value: 4, label: '6-10', multiplier: 1.35 },
      { value: 5, label: '10+', multiplier: 1.49 }
    ]},
    urgency: { value: 2, name: 'Timeline', description: 'Duration', scale: [
      { value: 1, label: '3+ months', multiplier: 1.0 },
      { value: 2, label: '2-3 months', multiplier: 1.0 },
      { value: 3, label: '1-2 months', multiplier: 1.14 },
      { value: 4, label: '2-4 weeks', multiplier: 1.28 }
    ]},
    multiBusinessUnit: { value: 1, name: 'Business Units', description: 'Domains', scale: [
      { value: 1, label: 'Single', multiplier: 1.0 },
      { value: 2, label: '2-3', multiplier: 1.28 },
      { value: 3, label: '4+', multiplier: 1.63 }
    ]},
    training: { value: 1, name: 'Training', description: 'Enablement', scale: [
      { value: 1, label: 'Basic', multiplier: 1.0 },
      { value: 2, label: 'Team', multiplier: 1.14 },
      { value: 3, label: 'Multi-team', multiplier: 1.28 }
    ]},
    systemCleanup: { value: 1, name: 'Data Cleanup', description: 'Quality', scale: [
      { value: 1, label: 'Clean', multiplier: 1.0 },
      { value: 2, label: 'Moderate', multiplier: 1.14 },
      { value: 3, label: 'Heavy', multiplier: 1.35 }
    ]}
  });

  const calculations = useMemo(() => {
    const enabled = Object.entries(hubs)
      .filter(([_, h]) => h.enabled)
      .map(([key, h]) => ({ key, name: h.name, tier: h.tier, baseCost: h.pricing[h.tier] }));
    
    enabled.sort((a, b) => b.baseCost - a.baseCost);
    
    let baseTotal = 0;
    if (enabled.length > 0) {
      baseTotal = enabled[0].baseCost;
      for (let i = 1; i < enabled.length; i++) {
        const hub = enabled[i];
        baseTotal += hub.key === 'cmsHub' ? hub.baseCost : (hub.tier === 'professional' ? 1500 : 3500);
      }
    }
    
    let riskMultiplier = 1.0;
    Object.values(riskFactors).forEach(factor => {
      const scale = factor.scale.find(s => s.value === factor.value);
      if (scale) riskMultiplier *= scale.multiplier;
    });
    
    const riskAdjustment = baseTotal * (riskMultiplier - 1);
    
    return {
      enabledHubs: enabled,
      baseTotal,
      riskAdjustment,
      startingPrice: baseTotal + riskAdjustment,
      riskMultiplier
    };
  }, [hubs, riskFactors]);

  const risk = useMemo(() => {
    const m = calculations.riskMultiplier;
    if (m < 2.0) return { label: 'Low Complexity', color: 'text-green-600', bg: 'bg-green-50' };
    if (m < 3.5) return { label: 'Medium Complexity', color: 'text-yellow-600', bg: 'bg-yellow-50' };
    return { label: 'High Complexity', color: 'text-orange-600', bg: 'bg-orange-50' };
  }, [calculations.riskMultiplier]);

  const handleSubmit = () => {
    if (!formData.firstName || !formData.lastName || !formData.email) {
      alert('Please fill all fields');
      return;
    }
    
    setIsSubmitting(true);
    
    fetch('https://api.hsforms.com/submissions/v3/integration/submit/45394285/729fd378-69d5-46d7-8810-984e33fe3678', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        submittedAt: Date.now(),
        fields: [
          { objectTypeId: "0-1", name: 'firstname', value: formData.firstName },
          { objectTypeId: "0-1", name: 'lastname', value: formData.lastName },
          { objectTypeId: "0-1", name: 'email', value: formData.email }
        ],
        context: { pageUri: window.location.href, pageName: 'Calculator' }
      })
    }).then(() => {
      setFormSubmitted(true);
      setShowForm(false);
      setIsSubmitting(false);
    }).catch(() => {
      setFormSubmitted(true);
      setShowForm(false);
      setIsSubmitting(false);
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-blue-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="flex items-center gap-3 mb-3">
            <Calculator className="w-8 h-8" />
            <div>
              <h1 className="text-3xl font-bold text-gray-800">HubSpot Onboarding Calculator</h1>
              <p className="text-gray-600">Your HS Expert - Starting Price Estimator</p>
            </div>
          </div>
          <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
            <p className="text-sm text-gray-700">
              <span className="font-semibold">Quick Estimate:</span> This calculator provides a rough starting estimate based on typical projects. Book a free discovery call with us to discuss your specific needs and get an accurate final estimate tailored to your business.
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-start justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800">Select HubSpot Hubs</h2>
                <div className="text-right">
                  <div className="text-xs text-gray-500 mb-1">Multi-Hub Pricing</div>
                  <div className="text-xs font-medium text-gray-700">
                    <div>1st Hub: Full Price</div>
                    <div className="text-green-600">Additional Pro: +$1,500</div>
                    <div className="text-green-600">Additional Ent: +$3,500</div>
                  </div>
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                {Object.entries(hubs).map(([key, hub]) => (
                  <div
                    key={key}
                    onClick={() => setHubs(prev => ({ ...prev, [key]: { ...prev[key], enabled: !prev[key].enabled } }))}
                    className={`border-2 rounded-xl p-5 cursor-pointer transition-all ${
                      hub.enabled ? 'border-orange-500 bg-orange-50 shadow-md' : 'border-gray-200 bg-white hover:border-orange-300'
                    }`}
                  >
                    <div className="flex items-start gap-3 mb-4">
                      <input type="checkbox" checked={hub.enabled} readOnly className="w-5 h-5 mt-0.5 cursor-pointer" />
                      <div className="flex-1">
                        <h3 className="font-bold text-gray-800 text-lg">{hub.name}</h3>
                        <div className="text-xs text-gray-500 mt-1">
                          {key === 'salesHub' && 'CRM, Sales Automation & Pipeline'}
                          {key === 'marketingHub' && 'Email, Ads & Lead Generation'}
                          {key === 'serviceHub' && 'Ticketing, Knowledge Base & Help Desk'}
                          {key === 'cmsHub' && 'Website & Landing Pages'}
                        </div>
                      </div>
                    </div>
                    
                    {hub.enabled && (
                      <div className="space-y-2 ml-8">
                        {['professional', 'enterprise'].map(tier => (
                          <label
                            key={tier}
                            onClick={(e) => { e.stopPropagation(); setHubs(prev => ({ ...prev, [key]: { ...prev[key], tier } })); }}
                            className={`flex items-center justify-between p-3 rounded-lg cursor-pointer ${
                              hub.tier === tier ? 'bg-orange-500 text-white shadow-sm' : 'bg-gray-100 hover:bg-gray-200'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <input type="radio" checked={hub.tier === tier} readOnly />
                              <span className="font-semibold text-sm capitalize">{tier}</span>
                            </div>
                            <span className="text-sm font-bold">${hub.pricing[tier].toLocaleString()}</span>
                          </label>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-6">Risk & Cost Drivers</h2>
              <div className="grid md:grid-cols-2 gap-5">
                {Object.entries(riskFactors).map(([key, factor]) => {
                  const current = factor.scale.find(s => s.value === factor.value);
                  const max = Math.max(...factor.scale.map(s => s.value));
                  
                  return (
                    <div key={key} className="bg-gradient-to-br from-gray-50 to-white border border-gray-200 rounded-xl p-5">
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1">
                          <h3 className="font-bold text-gray-800">{factor.name}</h3>
                          <p className="text-xs text-gray-500 mt-1">{factor.description}</p>
                        </div>
                        <div className="ml-3 px-3 py-1 bg-orange-500 text-white rounded-full text-sm font-bold">
                          {current.multiplier}x
                        </div>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max={max}
                        step="0.01"
                        value={factor.value}
                        onChange={(e) => {
                          const newValue = parseFloat(e.target.value);
                          const closest = factor.scale.reduce((prev, curr) => 
                            Math.abs(curr.value - newValue) < Math.abs(prev.value - newValue) ? curr : prev
                          );
                          setRiskFactors(prev => ({ ...prev, [key]: { ...prev[key], value: closest.value } }));
                        }}
                        className="w-full h-2 bg-gray-200 rounded-lg mb-3 cursor-pointer accent-orange-500"
                        style={{
                          background: `linear-gradient(to right, #f97316 0%, #f97316 ${((factor.value - 1) / (max - 1)) * 100}%, #e5e7eb ${((factor.value - 1) / (max - 1)) * 100}%, #e5e7eb 100%)`
                        }}
                      />
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold text-gray-700">{current.label}</span>
                        <div className="flex gap-1">
                          {factor.scale.map(s => (
                            <div key={s.value} className={`w-2 h-2 rounded-full ${s.value === current.value ? 'bg-orange-500' : 'bg-gray-300'}`} />
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div>
            <div className="bg-white rounded-xl shadow-lg p-6 sticky top-4">
              <h2 className="text-xl font-bold text-gray-800 mb-4">Starting Estimate</h2>
              
              {calculations.enabledHubs.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Calculator className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>Select at least one Hub</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-2 relative">
                    {calculations.enabledHubs.map((hub, i) => {
                      const cost = i === 0 ? hub.baseCost : (hub.key === 'cmsHub' ? hub.baseCost : (hub.tier === 'professional' ? 1500 : 3500));
                      return (
                        <div key={hub.key} className="flex justify-between text-sm">
                          <span className="text-gray-600">
                            {hub.name} ({hub.tier})
                            {i > 0 && hub.key !== 'cmsHub' && <span className="text-xs text-green-600 ml-1">(additional)</span>}
                          </span>
                          <span className={`font-medium ${!formSubmitted && 'blur-content'}`}>${cost.toLocaleString()}</span>
                        </div>
                      );
                    })}
                    <div className="border-t pt-2 flex justify-between font-semibold">
                      <span>Subtotal</span>
                      <span className={!formSubmitted ? 'blur-content' : ''}>${calculations.baseTotal.toLocaleString()}</span>
                    </div>
                    {calculations.riskAdjustment > 0 && (
                      <div className="flex justify-between text-sm text-orange-600">
                        <span>Risk Adjustment</span>
                        <span className={!formSubmitted ? 'blur-content' : ''}>+${Math.round(calculations.riskAdjustment).toLocaleString()}</span>
                      </div>
                    )}
                  </div>

                  <div className={`p-4 ${risk.bg} rounded-lg border-2 relative`}>
                    <div className="flex items-center gap-2 mb-2">
                      <AlertCircle className={`w-5 h-5 ${risk.color}`} />
                      <span className="font-semibold text-gray-700">Complexity</span>
                    </div>
                    <div className={`text-lg font-bold ${risk.color} ${!formSubmitted && 'blur-content'}`}>{calculations.riskMultiplier.toFixed(2)}x</div>
                    <div className="text-sm text-gray-600 mt-1">{risk.label}</div>
                  </div>

                  <div className="p-5 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg relative">
                    <div className="flex items-center gap-2 mb-2">
                      <DollarSign className="w-6 h-6" />
                      <span className="text-sm font-medium opacity-90">Starting Price</span>
                    </div>
                    <div className={`text-4xl font-bold mb-1 ${!formSubmitted && 'blur-content'}`}>${Math.round(calculations.startingPrice).toLocaleString()}</div>
                    <div className="text-xs opacity-90">Subject to discovery and scope review</div>
                  </div>

                  {!formSubmitted ? (
                    <button onClick={() => setShowForm(true)} className="w-full flex items-center justify-center gap-2 bg-orange-500 text-white px-4 py-3 rounded-lg hover:bg-orange-600 font-semibold shadow-lg">
                      <Calendar className="w-5 h-5" />
                      Unlock Your Estimate
                    </button>
                  ) : (
                    <a href="https://yourhubspotexpert.com/book-a-call" target="_blank" rel="noopener noreferrer" className="w-full flex items-center justify-center gap-2 bg-orange-500 text-white px-4 py-3 rounded-lg hover:bg-orange-600 font-semibold shadow-lg">
                      <Calendar className="w-5 h-5" />
                      Book a Call
                    </a>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 relative">
            <button onClick={() => setShowForm(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
              <X className="w-6 h-6" />
            </button>
            
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8 text-orange-500" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">See Your Starting Price</h3>
              <p className="text-gray-600 text-sm">Enter your details to unlock your estimate</p>
              <div className="mt-3 bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-xs text-gray-700">
                  <span className="font-semibold">Note:</span> This is a rough estimate. Book a discovery call for an accurate quote tailored to your needs.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">First Name *</label>
                <input
                  type="text"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg"
                  placeholder="John"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Last Name *</label>
                <input
                  type="text"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg"
                  placeholder="Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Email *</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg"
                  placeholder="john@company.com"
                />
              </div>
              <button 
                onClick={handleSubmit} 
                disabled={isSubmitting} 
                className="w-full bg-orange-500 text-white py-3 rounded-lg hover:bg-orange-600 font-semibold disabled:opacity-50"
              >
                {isSubmitting ? 'Submitting...' : 'Show My Estimate'}
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`.blur-content{filter:blur(8px);pointer-events:none;}`}</style>
    </div>
  );
};

export default HubSpotCalculator;