# Your HS Expert - HubSpot Solutions Partner Website

## Overview
"Your HS Expert" is a professional B2B SaaS marketing website for a certified HubSpot Solutions Partner. The site showcases HubSpot implementation, migration, and consulting services with a focus on modern design and conversion optimization. It is built as a React single-page application with an Express backend, featuring case studies, service offerings, and integrated HubSpot functionalities like calendar booking and an interactive cost calculator for lead generation. The business vision is to provide a robust online presence that highlights expertise and drives client engagement in the HubSpot ecosystem.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Technology Stack**: React 18 (TypeScript), Vite, Wouter (routing), TanStack Query (data fetching), Shadcn/ui (component library).
- **UI Design System**: Tailwind CSS with custom HubSpot-inspired color palette (orange primary), dark mode support, Inter font. Emphasizes a modern B2B SaaS aesthetic.
- **Component Structure**: Page-based components (Home, HubSpotOnboarding, NotFound), reusable sections (Header, Hero, Services, Contact, Footer, etc.), and a comprehensive UI component library. Includes an interactive `HubSpotCalculator`.
- **Key Features**: Dynamic SEO meta tags (React Helmet Async), animations (Framer Motion), content sliders (Embla Carousel), icon system (Lucide React, React Icons), form validation (React Hook Form with Zod).

### Backend
- **Server Framework**: Express.js with TypeScript for API endpoints.
- **Development Setup**: `tsx` with hot reload for development, Vite for client and esbuild for server bundle in production.
- **Authentication**: Replit Auth (OpenID Connect) for secure user authentication. Supports email/password, Google, GitHub, Apple, and X login. Admin role system controls access to CMS features.
- **API Layer**: RESTful API for full CRUD operations on content (blogs, case studies), categories, and tags. Includes search, popular content fetching, and slug conflict handling. All mutation endpoints protected with admin authentication.
- **CMS Implementation**: Unified content management system for blogs and case studies. Includes features like view tracking, reading time calculation, and status management (published/draft).
- **Admin Interface**: `/admin` route provides a password-protected CMS dashboard with authentication, markdown editor, image uploads, content listing with filters, and inline editing. Requires admin role for access.

### System Design
- **UI/UX**: Emphasis on a professional B2B SaaS aesthetic with modern minimalism, conversion-focused design, and accessible components. Consistent branding with HubSpot's orange identity.
- **Technical Implementations**: Type-safe development with TypeScript, client-side routing, efficient state management, and utility-first styling.
- **Feature Specifications**:
    - **HubSpot Onboarding Page**: Features an interactive cost calculator for services with dynamic pricing and lead capture integrated with HubSpot Forms API.
    - **Content Pages**: Dedicated pages for Case Studies and Blog Posts, including listing pages with filtering, individual detail pages with markdown rendering, and SEO optimization.
    - **Book a Call Page** (/book-call): Dedicated conversion page with trust-building elements (stats, certifications), HubSpot calendar embed, and social proof (testimonials, results highlights) to maximize booking conversions.
    - **Animations**: Subtle, professional animations using Framer Motion across the site for enhanced user experience.
    - **UTM Tracking**: Dynamic UTM parameters on all content CTAs to track conversions. Blog posts use utm_source=blog, case studies use utm_source=case_studies, with campaign set to content slug. Enables ROI measurement and content attribution in GA4/HubSpot. See UTM_TRACKING.md for details.

## Sample Content Data
The database includes sample content for demonstration:

**Blog Posts:**
- "5 HubSpot Automation Tips to Save Hours Every Week" - Practical automation strategies
- "Migrating to HubSpot: A Complete Checklist" - Migration planning guide

**Case Studies:**
- "How Tosi Improved Lead Quality by 200% with HubSpot"
  - Company: Tosi (Industrial Technology)
  - Metrics: 200% lead quality increase, 3x MQL growth, 45% sales cycle reduction
  - Testimonial from VP of Marketing
- "SaaS Startup Cuts Customer Onboarding Time by 60%"
  - Company: CloudFlow (SaaS)
  - Metrics: 60% faster onboarding, 40% support reduction, 95% satisfaction
  - Testimonial from Head of Customer Success

**Categories:** HubSpot Tips, Implementation, Migration, Success Stories
**Tags:** automation, workflow, migration, ROI, integration

## External Dependencies

- **Database & ORM**: PostgreSQL via Drizzle ORM and Neon Database serverless driver. Schema defined in `shared/schema.ts` with Zod validation.
- **Authentication**: 
    - **Replit Auth (OpenID Connect)**: Integrated authentication provider supporting multiple login methods
    - **Session Storage**: PostgreSQL-backed sessions for persistent authentication
    - **Admin Role System**: Database-level role management for CMS access control
- **Third-Party Integrations**:
    - **HubSpot Meetings Embed**: Integrated calendar booking widget.
    - **HubSpot Forms API**: For lead capture forms, specifically the `HubSpotCalculator`.
- **Object Storage**: Replit Object Storage for image uploads, supporting public and private file serving with presigned URL generation.
- **Libraries**:
    - `@uiw/react-md-editor`: Markdown editing.
    - `Uppy`: File upload component.
    - `passport` + `openid-client`: Authentication middleware.

## Admin Access Setup

### Granting Admin Access
To grant admin access to a user:

1. User must first log in to the application via `/api/login`
2. Find their user ID in the database
3. Update their admin status:
```sql
UPDATE users SET is_admin = true WHERE email = 'user@example.com';
```

### Authentication Flow
1. User visits `/admin`
2. If not logged in, redirected to `/api/login`
3. After login via Replit Auth (email/password, Google, GitHub, etc.)
4. Redirected back to `/admin`
5. Access granted if `isAdmin = true`, otherwise shown access denied

### Protected Routes
- **Frontend**: `/admin` - CMS admin panel (requires authentication + admin role)
- **Backend API**:
  - POST `/api/content` - Create content
  - PATCH `/api/content/:id` - Update content
  - DELETE `/api/content/:id` - Delete content
  - All category/tag mutations
  - All object storage uploads

### Logout
Users can logout via:
- Logout button in CMS admin header
- Direct navigation to `/api/logout`